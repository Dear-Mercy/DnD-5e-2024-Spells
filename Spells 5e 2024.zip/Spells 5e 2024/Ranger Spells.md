
|   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
|[[Aid]]|2|abjuration|Action|30 ft|8 hours|V,S,M|||
|[[Alarm]]|1|abjuration|1 minute or Ritual|30 ft|8 hours|V,S,M||Ritual|
|[[Animal Friendship]]|1|enchantment|Action|30 ft|24 hours|V,S,M|||
|[[Animal Messenger]]|2|enchantment|Action or Ritual|30 ft|24 hours|V,S,M||Ritual|
|[[Barkskin]]|2|transmutation|Bonus Action|Touch|1 hour|V,S,M|||
|[[Beast Sense]]|2|divination|Action or Ritual|Touch|1 hour|S|Concentration|Ritual|
|[[Commune with Nature]]|5|divination|1 minute or Ritual|Self|Instantaneous|V,S||Ritual|
|[[Conjure Animals]]|3|conjuration|Action|60 ft|10 minutes|V,S|Concentration|   |
|[[Conjure Barrage]]|3|conjuration|Action|Self|Instantaneous|V,S,M|||
|[[Conjure Volley]]|5|conjuration|Action|150 ft|Instantaneous|V,S,M|||
|[[Conjure Woodland Beings]]|4|conjuration|Action|Self|10 minutes|V,S|Concentration|   |
|[[Cordon of Arrows]]|2|transmutation|Action|Touch|8 hours|V,S,M|||
|[[Cure Wounds]]|1|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Darkvision]]|2|transmutation|Action|Touch|8 hours|V,S,M|||
|[[Daylight]]|3|evocation|Action|60 ft|1 hour|V,S|||
|[[Detect Magic]]|1|divination|Action or Ritual|Self|10 minutes|V,S|Concentration|Ritual|
|[[Detect Poison and Disease]]|1|divination|Action or Ritual|Self|10 minutes|V,S,M|Concentration|Ritual|
|[[Dispel Magic]]|3|abjuration|Action|120 ft|Instantaneous|V,S|||
|[[Dominate Beast]]|4|enchantment|Action|60 ft|1 minute|V,S|Concentration|   |
|[[Elemental Weapon]]|3|transmutation|Action|Touch|1 hour|V,S|Concentration|   |
|[[Enhance Ability]]|2|transmutation|Action|Touch|1 hour|V,S,M|Concentration|   |
|[[Ensnaring Strike]]|1|conjuration|Bonus Action|Self|1 minute|V|Concentration|   |
|[[Entangle]]|1|conjuration|Action|90 ft|1 minute|V,S|Concentration|   |
|[[Find Traps]]|2|divination|Action|120 ft|Instantaneous|V,S|||
|[[Fog Cloud]]|1|conjuration|Action|120 ft|1 hour|V,S|Concentration|   |
|[[Freedom of Movement]]|4|abjuration|Action|Touch|1 hour|V,S,M|||
|[[Goodberry]]|1|conjuration|Action|Self|24 hours|V,S,M|||
|[[Grasping Vine]]|4|conjuration|Bonus Action|60 ft|1 minute|V,S|Concentration|   |
|[[Greater Restoration]]|5|abjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Gust of Wind]]|2|evocation|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Hail of Thorns]]|1|conjuration|Bonus Action|Self|Instantaneous|V|||
|[[Hunter's Mark]]|1|divination|Bonus Action|90 ft|1 hour|V|Concentration|   |
|[[Jump]]|1|transmutation|Bonus Action|Touch|1 minute|V,S,M|||
|[[Lesser Restoration]]|2|abjuration|Bonus Action|Touch|Instantaneous|V,S|||
|[[Lightning Arrow]]|3|transmutation|Bonus Action|Self|Instantaneous|V,S|||
|[[Locate Animals or Plants]]|2|divination|Action or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Locate Creature]]|4|divination|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Locate Object]]|2|divination|Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Longstrider]]|1|transmutation|Action|Touch|1 hour|V,S,M|||
|[[Magic Weapon]]|2|transmutation|Bonus Action|Touch|1 hour|V,S|||
|[[Meld into Stone]]|3|transmutation|Action or Ritual|Touch|8 hours|V,S||Ritual|
|[[Nondetection]]|3|abjuration|Action|Touch|8 hours|V,S,M|||
|[[Pass without Trace]]|2|abjuration|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Plant Growth]]|3|transmutation|Action (Overgrowth) or 8 hours (Enrichment)|150 ft|Instantaneous|V,S|||
|[[Protection from Energy]]|3|abjuration|Action|Touch|1 hour|V,S|Concentration|   |
|[[Protection from Poison]]|2|abjuration|Action|Touch|1 hour|V,S|||
|[[Revivify]]|3|necromancy|Action|Touch|Instantaneous|V,S,M|||
|[[Silence]]|2|illusion|Action or Ritual|120 ft|10 minutes|V,S|Concentration|Ritual|
|[[Speak with Animals]]|1|divination|Action or Ritual|Self|10 minutes|V,S||Ritual|
|[[Speak with Plants]]|3|transmutation|Action|Self|10 minutes|V,S|||
|[[Spike Growth]]|2|transmutation|Action|150 ft|10 minutes|V,S,M|Concentration|   |
|[[Steel Wind Strike]]|5|conjuration|Action|30 ft|Instantaneous|S,M|||
|[[Stoneskin]]|4|transmutation|Action|Touch|1 hour|V,S,M|Concentration|   |
|[[Summon Beast]]|2|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Summon Elemental]]|4|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Summon Fey]]|3|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Swift Quiver]]|5|transmutation|Bonus Action|Self|1 minute|V,S,M|Concentration|   |
|[[Tree Stride]]|5|conjuration|Action|Self|1 minute|V,S|Concentration|   |
|[[Water Breathing]]|3|transmutation|Action or Ritual|30 ft|24 hours|V,S,M||Ritual|
|[[Water Walk]]|3|transmutation|Action or Ritual|30 ft|1 hour|V,S,M||Ritual|
|[[Wind Wall]]|3|evocation|Action|120 ft|1 minute|V,S,M|Concentration|   |
