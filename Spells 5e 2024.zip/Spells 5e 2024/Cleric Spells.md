|   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
|[[Aid]]|2|abjuration|Action|30 ft|8 hours|V,S,M|||
|[[Animate Dead]]|3|necromancy|1 minute|10 ft|Instantaneous|V,S,M|||
|[[Antimagic Field]]|8|abjuration|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Astral Projection]]|9|necromancy|1 hour|10 ft|Dispelled|V,S,M|||
|[[Augury]]|2|divination|1 minute or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Aura of Life]]|4|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Aura of Purity]]|4|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Aura of Vitality]]|3|abjuration|Action|Self|1 minute|V|Concentration|   |
|[[Bane]]|1|enchantment|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Banishment]]|4|abjuration|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Beacon of Hope]]|3|abjuration|Action|30 ft|1 minute|V,S|Concentration|   |
|[[Bestow Curse]]|3|necromancy|Action|Touch|1 minute|V,S|Concentration|   |
|[[Blade Barrier]]|6|evocation|Action|90 ft|10 minutes|V,S|Concentration|   |
|[[Bless]]|1|enchantment|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Blindness Deafness]]|2|transmutation|Action|120 ft|1 minute|V|||
|[[Calm Emotions]]|2|enchantment|Action|60 ft|1 minute|V,S|Concentration|   |
|[[Circle of Power]]|5|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Clairvoyance]]|3|divination|10 minutes|1 mile|10 minutes|V,S,M|Concentration|   |
|[[Command]]|1|enchantment|Action|60 ft|Instantaneous|V|||
|[[Commune]]|5|divination|1 minute or Ritual|Self|1 minute|V,S,M||Ritual|
|[[Conjure Celestial]]|7|conjuration|Action|90 ft|10 minutes|V,S|Concentration|   |
|[[Contagion]]|5|necromancy|Action|Touch|7 days|V,S|||
|[[Continual Flame]]|2|evocation|Action|Touch|Dispelled|V,S,M|||
|[[Control Water]]|4|transmutation|Action|300 ft|10 minutes|V,S,M|Concentration|   |
|[[Control Weather]]|8|transmutation|10 minutes|Self|8 hours|V,S,M|Concentration|   |
|[[Create Food and Water]]|3|conjuration|Action|30 ft|Instantaneous|V,S|||
|[[Create or Destroy Water]]|1|transmutation|Action|30 ft|Instantaneous|V,S,M|||
|[[Create Undead]]|6|necromancy|1 minute|10 ft|Instantaneous|V,S,M|||
|[[Cure Wounds]]|1|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Daylight]]|3|evocation|Action|60 ft|1 hour|V,S|||
|[[Death Ward]]|4|abjuration|Action|Touch|8 hours|V,S|||
|[[Detect Evil and Good]]|1|divination|Action|Self|10 minutes|V,S|Concentration|   |
|[[Detect Magic]]|1|divination|Action or Ritual|Self|10 minutes|V,S|Concentration|Ritual|
|[[Detect Poison and Disease]]|1|divination|Action or Ritual|Self|10 minutes|V,S,M|Concentration|Ritual|
|[[Dispel Evil and Good]]|5|abjuration|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Dispel Magic]]|3|abjuration|Action|120 ft|Instantaneous|V,S|||
|[[Divination]]|4|divination|Action or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Divine Word]]|7|evocation|Bonus Action|30 ft|Instantaneous|V|||
|[[Earthquake]]|8|transmutation|Action|500 ft|1 minute|V,S,M|Concentration|   |
|[[Enhance Ability]]|2|transmutation|Action|Touch|1 hour|V,S,M|Concentration|   |
|[[Etherealness]]|7|conjuration|Action|Self|8 hours|V,S|||
|[[Feign Death]]|3|necromancy|Action or Ritual|Touch|1 hour|V,S,M||Ritual|
|[[Find the Path]]|6|divination|1 minute|Self|1 day|V,S,M|Concentration|   |
|[[Find Traps]]|2|divination|Action|120 ft|Instantaneous|V,S|||
|[[Fire Storm]]|7|evocation|Action|150 ft|Instantaneous|V,S|||
|[[Flame Strike]]|5|evocation|Action|60 ft|Instantaneous|V,S,M|||
|[[Forbiddance]]|6|abjuration|10 minutes or Ritual|Touch|1 day|V,S,M||Ritual|
|[[Freedom of Movement]]|4|abjuration|Action|Touch|1 hour|V,S,M|||
|[[Gate]]|9|conjuration|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Geas]]|5|enchantment|1 minute|60 ft|30 days|V|||
|[[Gentle Repose]]|2|necromancy|Action or Ritual|Touch|10 days|V,S,M||Ritual|
|[[Glyph of Warding]]|3|abjuration|1 hour|Touch|Dispelled or triggered|V,S,M|||
|[[Greater Restoration]]|5|abjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Guardian of Faith]]|4|conjuration|Action|30 ft|8 hours|V|||
|[[Guidance]]|0|divination|Action|Touch|1 minute|V,S|Concentration|   |
|[[Guiding Bolt]]|1|evocation|Action|120 ft|1 round|V,S|||
|[[Hallow]]|5|abjuration|24 hours|Touch|Dispelled|V,S,M|||
|[[Harm]]|6|necromancy|Action|60 ft|Instantaneous|V,S|||
|[[Heal]]|6|abjuration|Action|60 ft|Instantaneous|V,S|||
|[[Healing Word]]|1|abjuration|Bonus Action|60 ft|Instantaneous|V|||
|[[Heroes' Feast]]|6|conjuration|10 minutes|Self|Instantaneous|V,S,M|||
|[[Hold Person]]|2|enchantment|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Holy Aura]]|8|abjuration|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Inflict Wounds]]|1|necromancy|Action|Touch|Instantaneous|V,S|||
|[[Insect Plague]]|5|conjuration|Action|300 ft|10 minutes|V,S,M|Concentration|   |
|[[Legend Lore]]|5|divination|10 minutes|Self|Instantaneous|V,S,M|||
|[[Lesser Restoration]]|2|abjuration|Bonus Action|Touch|Instantaneous|V,S|||
|[[Light]]|0|evocation|Action|Touch|1 hour|V,M|||
|[[Locate Creature]]|4|divination|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Locate Object]]|2|divination|Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Magic Circle]]|3|abjuration|1 minute|10 ft|1 hour|V,S,M|||
|[[Mass Cure Wounds]]|5|abjuration|Action|60 ft|Instantaneous|V,S|||
|[[Mass Heal]]|9|abjuration|Action|60 ft|Instantaneous|V,S|||
|[[Mass Healing Word]]|3|abjuration|Bonus Action|60 ft|Instantaneous|V|||
|[[Meld into Stone]]|3|transmutation|Action or Ritual|Touch|8 hours|V,S||Ritual|
|[[Mending]]|0|transmutation|1 minute|Touch|Instantaneous|V,S,M|||
|[[Planar Ally]]|6|conjuration|10 minutes|60 ft|Instantaneous|V,S|||
|[[Planar Binding]]|5|abjuration|1 hour|60 ft|24 hours|V,S,M|||
|[[Plane Shift]]|7|conjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Power Word Fortify]]|7|enchantment|Action|60 ft|Instantaneous|V|||
|[[Power Word Heal]]|9|enchantment|Action|60 ft|Instantaneous|V|||
|[[Prayer of Healing]]|2|abjuration|10 minutes|30 ft|Instantaneous|V|||
|[[Protection from Energy]]|3|abjuration|Action|Touch|1 hour|V,S|Concentration|   |
|[[Protection from Evil and Good]]|1|abjuration|Action|Touch|10 minutes|V,S,M|Concentration|   |
|[[Protection from Poison]]|2|abjuration|Action|Touch|1 hour|V,S|||
|[[Purify Food and Drink]]|1|transmutation|Action or Ritual|10 ft|Instantaneous|V,S||Ritual|
|[[Raise Dead]]|5|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[Regenerate]]|7|transmutation|1 minute|Touch|1 hour|V,S,M|||
|[[Remove Curse]]|3|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Resistance]]|0|abjuration|Action|Touch|1 minute|V,S|Concentration|   |
|[[Resurrection]]|7|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[Revivify]]|3|necromancy|Action|Touch|Instantaneous|V,S,M|||
|[[Sacred Flame]]|0|evocation|Action|60 ft|Instantaneous|V,S|||
|[[Sanctuary]]|1|abjuration|Bonus Action|30 ft|1 minute|V,S,M|||
|[[Scrying]]|5|divination|10 minutes|Self|10 minutes|V,S,M|Concentration|   |
|[[Sending]]|3|divination|Action|Unlimited|Instantaneous|V,S,M|||
|[[Shield of Faith]]|1|abjuration|Bonus Action|60 ft|10 minutes|V,S,M|Concentration|   |
|[[Silence]]|2|illusion|Action or Ritual|120 ft|10 minutes|V,S|Concentration|Ritual|
|[[Spare the Dying]]|0|necromancy|Action|15 ft|Instantaneous|V,S|||
|[[Speak with Dead]]|3|necromancy|Action|10 ft|10 minutes|V,S,M|||
|[[Spirit Guardians]]|3|conjuration|Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Spiritual Weapon]]|2|evocation|Bonus Action|60 ft|1 minute|V,S|Concentration|   |
|[[Stone Shape]]|4|transmutation|Action|Touch|Instantaneous|V,S,M|||
|[[Summon Celestial]]|5|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Sunbeam]]|6|evocation|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Sunburst]]|8|evocation|Action|150 ft|Instantaneous|V,S,M|||
|[[Symbol]]|7|abjuration|1 minute|Touch|Dispelled or triggered|V,S,M|||
|[[Thaumaturgy]]|0|transmutation|Action|30 ft|1 minute|V|||
|[[Toll the Dead]]|0|necromancy|Action|60 ft|Instantaneous|V,S|||
|[[Tongues]]|3|divination|Action|Touch|1 hour|V,M|||
|[[True Resurrection]]|9|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[True Seeing]]|6|divination|Action|Touch|1 hour|V,S,M|||
|[[Warding Bond]]|2|abjuration|Action|Touch|1 hour|V,S,M|||
|[[Water Walk]]|3|transmutation|Action or Ritual|30 ft|1 hour|V,S,M||Ritual|
|[[Word of Radiance]]|0|evocation|Action|Self|Instantaneous|V,M|||
|[[Word of Recall]]|6|conjuration|Action|5 ft|Instantaneous|V|||
|[[Zone of Truth]]|2|enchantment|Action|60 ft|10 minutes|V,S|||