|   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|
|[[Arcane Gate]]|6|conjuration|Action|500 ft|10 minutes|V,S|Concentration|
|[[Armor of Agathys]]|1|abjuration|Bonus Action|Self|1 hour|V,S,M||
|[[Arms of Hadar]]|1|conjuration|Action|Self|Instantaneous|V,S||
|[[Astral Projection]]|9|necromancy|1 hour|10 ft|Dispelled|V,S,M||
|[[Bane]]|1|enchantment|Action|30 ft|1 minute|V,S,M|Concentration|
|[[Banishment]]|4|abjuration|Action|30 ft|1 minute|V,S,M|Concentration|
|[[Befuddlement]]|8|enchantment|Action|150 ft|Instantaneous|V,S,M||
|[[Blade Ward]]|0|abjuration|Action|Self|1 minute|V,S|Concentration|
|[[Blight]]|4|necromancy|Action|30 ft|Instantaneous|V,S||
|[[Charm Monster]]|4|enchantment|Action|30 ft|1 hour|V,S||
|[[Charm Person]]|1|enchantment|Action|30 ft|1 hour|V,S||
|[[Chill Touch]]|0|necromancy|Action|Touch|Instantaneous|V,S||
|[[Circle of Death]]|6|necromancy|Action|150 ft|Instantaneous|V,S,M||
|[[Cloud of Daggers]]|2|conjuration|Action|60 ft|1 minute|V,S,M|Concentration|
|[[Comprehend Languages]]|1|divination|Action or Ritual|Self|1 hour|V,S,M||
|[[Contact Other Plane]]|5|divination|1 minute or Ritual|Self|1 minute|V||
|[[Counterspell]]|3|abjuration|Reaction|60 ft|Instantaneous|S||
|[[Create Undead]]|6|necromancy|1 minute|10 ft|Instantaneous|V,S,M||
|[[Crown of Madness]]|2|enchantment|Action|120 ft|1 minute|V,S|Concentration|
|[[Darkness]]|2|evocation|Action|60 ft|10 minutes|V,M|Concentration|
|[[Demiplane]]|8|conjuration|Action|60 ft|1 hour|S||
|[[Detect Magic]]|1|divination|Action or Ritual|Self|10 minutes|V,S|Concentration|
|[[Dimension Door]]|4|conjuration|Action|500 ft|Instantaneous|V||
|[[Dispel Magic]]|3|abjuration|Action|120 ft|Instantaneous|V,S||
|[[Dominate Monster]]|8|enchantment|Action|60 ft|1 hour|V,S|Concentration|
|[[Dream]]|5|illusion|1 minute|Special|8 hours|V,S,M||
|[[Eldritch Blast]]|0|evocation|Action|120 ft|Instantaneous|V,S||
|[[Enthrall]]|2|enchantment|Action|60 ft|1 minute|V,S|Concentration|
|[[Etherealness]]|7|conjuration|Action|Self|8 hours|V,S||
|[[Expeditious Retreat]]|1|transmutation|Bonus Action|Self|10 minutes|V,S|Concentration|
|[[Eyebite]]|6|necromancy|Action|Self|1 minute|V,S|Concentration|
|[[Fear]]|3|illusion|Action|Self|1 minute|V,S,M|Concentration|
|[[Finger of Death]]|7|necromancy|Action|60 ft|Instantaneous|V,S||
|[[Fly]]|3|transmutation|Action|Touch|10 minutes|V,S,M|Concentration|
|[[Forcecage]]|7|evocation|Action|100 ft|1 hour|V,S,M||
|[[Foresight]]|9|divination|1 minute|Touch|8 hours|V,S,M||
|[[Friends]]|0|enchantment|Action|10 ft|1 minute|S,M|Concentration|
|[[Gaseous Form]]|3|transmutation|Action|Touch|1 hour|V,S,M|Concentration|
|[[Gate]]|9|conjuration|Action|60 ft|1 minute|V,S,M|Concentration|
|[[Glibness]]|8|enchantment|Action|Self|1 hour|V||
|[[Hallucinatory Terrain]]|4|illusion|10 minutes|300 ft|24 hours|V,S,M||
|[[Hellish Rebuke]]|1|evocation|Reaction|60 ft|Instantaneous|V,S||
|[[Hex]]|1|enchantment|Bonus Action|90 ft|1 hour|V,S,M|Concentration|
|[[Hold Monster]]|5|enchantment|Action|90 ft|1 minute|V,S,M|Concentration|
|[[Hold Person]]|2|enchantment|Action|60 ft|1 minute|V,S,M|Concentration|
|[[Hunger of Hadar]]|3|conjuration|Action|150 ft|1 minute|V,S,M|Concentration|
|[[Hypnotic Pattern]]|3|illusion|Action|120 ft|1 minute|S,M|Concentration|
|[[Illusory Script]]|1|illusion|1 minute or Ritual|Touch|10 days|S,M||
|[[Imprisonment]]|9|abjuration|1 minute|30 ft|Dispelled|V,S,M||
|[[Invisibility]]|2|illusion|Action|Touch|1 hour|V,S,M|Concentration|
|[[Jallarzi's Storm of Radiance]]|5|evocation|Action|120 ft|1 minute|V,S,M|Concentration|
|[[Mage Hand]]|0|conjuration|Action|30 ft|1 minute|V,S||
|[[Magic Circle]]|3|abjuration|1 minute|10 ft|1 hour|V,S,M||
|[[Major Image]]|3|illusion|Action|120 ft|10 minutes|V,S,M|Concentration|
|[[Mind Sliver]]|0|enchantment|Action|60 ft|1 round|V||
|[[Mind Spike]]|2|divination|Action|120 ft|1 hour|S|Concentration|
|[[Minor Illusion]]|0|illusion|Action|30 ft|1 minute|S,M||
|[[Mirror Image]]|2|illusion|Action|Self|1 minute|V,S||
|[[Mislead]]|5|illusion|Action|Self|1 hour|S|Concentration|
|[[Misty Step]]|2|conjuration|Bonus Action|Self|Instantaneous|V||
|[[Planar Binding]]|5|abjuration|1 hour|60 ft|24 hours|V,S,M||
|[[Plane Shift]]|7|conjuration|Action|Touch|Instantaneous|V,S,M||
|[[Poison Spray]]|0|necromancy|Action|30 ft|Instantaneous|V,S||
|[[Power Word Kill]]|9|enchantment|Action|60 ft|Instantaneous|V||
|[[Power Word Stun]]|8|enchantment|Action|60 ft|Instantaneous|V||
|[[Prestidigitation]]|0|transmutation|Action|10 ft|1 hour|V,S||
|[[Protection from Evil and Good]]|1|abjuration|Action|Touch|10 minutes|V,S,M|Concentration|
|[[Ray of Enfeeblement]]|2|necromancy|Action|60 ft|1 minute|V,S|Concentration|
|[[Remove Curse]]|3|abjuration|Action|Touch|Instantaneous|V,S||
|[[Scrying]]|5|divination|10 minutes|Self|10 minutes|V,S,M|Concentration|
|[[Speak with Animals]]|1|divination|Action or Ritual|Self|10 minutes|V,S||
|[[Spider Climb]]|2|transmutation|Action|Touch|1 hour|V,S,M|Concentration|
|[[Suggestion]]|2|enchantment|Action|30 ft|8 hours|V,M|Concentration|
|[[Summon Aberration]]|4|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|
|[[Summon Fey]]|3|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|
|[[Summon Fiend]]|6|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|
|[[Summon Undead]]|3|necromancy|Action|90 ft|1 hour|V,S,M|Concentration|
|[[Synaptic Static]]|5|enchantment|Action|120 ft|Instantaneous|V,S||
|[[Tasha's Bubbling Cauldron]]|6|conjuration|Action|5 ft|10 minutes|V,S,M||
|[[Tasha's Hideous Laughter]]|1|enchantment|Action|30 ft|1 minute|V,S,M|Concentration|
|[[Teleportation Circle]]|5|conjuration|1 minute|10 ft|1 round|V,M||
|[[Thunderclap]]|0|evocation|Action|Self|Instantaneous|S||
|[[Toll the Dead]]|0|necromancy|Action|60 ft|Instantaneous|V,S||
|[[Tongues]]|3|divination|Action|Touch|1 hour|V,M||
|[[True Polymorph]]|9|transmutation|Action|30 ft|1 hour|V,S,M|Concentration|
|[[True Seeing]]|6|divination|Action|Touch|1 hour|V,S,M||
|[[True Strike]]|0|divination|Action|Self|Instantaneous|S,M||
|[[Unseen Servant]]|1|conjuration|Action or Ritual|60 ft|1 hour|V,S,M||
|[[Vampiric Touch]]|3|necromancy|Action|Self|1 minute|V,S|Concentration|
|[[Weird]]|9|illusion|Action|120 ft|1 minute|V,S|Concentration|
|[[Witch Bolt]]|1|evocation|Action|60 ft|1 minute|V,S,M|Concentration|