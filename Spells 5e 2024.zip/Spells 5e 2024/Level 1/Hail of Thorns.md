level 1 - #conjuration Casting Time: #BonusAction, which you take immediately after hitting a creature with a Ranged weapon Range: Self Components: V Duration: Instantaneous 

As you hit the creature, this spell creates a rain of thorns that sprouts from your Ranged weapon or ammunition. The target of the attack and each creature within 5 feet of it make a Dexterity saving throw, taking 1d10 Piercing damage on a failed save or half as much damage on a successful one. 

Using a Higher-Level Spell Slot. The damage increases by 1d10 for each spell slot level above 1.


#Ranger
