level 1 - #abjuration Casting Time: Action Range: Touch Components: V, S Duration: Instantaneous 

A creature you touch regains a number of Hit Points equal to 2d8 plus your spellcasting ability modifier. 

Using a Higher-Level Spell Slot. The healing increases by 2d8 for each spell slot level above 1


#Bard #Cleric #Druid #Paladin #Ranger
