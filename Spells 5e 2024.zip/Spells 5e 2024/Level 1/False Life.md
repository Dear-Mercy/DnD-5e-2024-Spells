level 1 - #necromancy Casting Time: Action Range: Self Components: V, S, M (a drop of alcohol) Duration: Instantaneous 

You gain 2d4 + 4 Temporary Hit Points. 

Using a Higher-Level Spell Slot. You gain 5 additional Temporary Hit Points for each spell slot level above 1.


#Sorcerer #Wizard
