level 1 - #transmutation Casting Time: Action Range: Touch Components: V, S, M (a pinch of dirt) Duration: 1 hour 

You touch a creature. The target's Speed increases by 10 feet until the spell ends. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 1


#Bard #Druid #Ranger #Wizard
