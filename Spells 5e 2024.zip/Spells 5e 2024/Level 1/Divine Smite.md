level 1 - #evocation Casting Time: #BonusAction, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike Range: Self Components: V Duration: Instantaneous 

The target takes an extra 2d8 Radiant damage from the attack. The damage increases by 1d8 if the target is a Fiend or an Undead. 

Using a Higher-Level Spell Slot. The damage increases by 1d8 for each spell slot level above 1


#Paladin
