level 1 - #abjuration Casting Time: #Reaction, which you take when you are hit by an attack roll or targeted by the Magic Missile spell Range: Self Components: V, S Duration: 1 round 

An imperceptible barrier of magical force protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from Magic Missile


#Sorcerer #Wizard
