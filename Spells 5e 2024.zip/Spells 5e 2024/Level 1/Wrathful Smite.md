level 1 - #necromancy Casting Time: #BonusAction, which you take immediately after hitting a creature with a Melee weapon or an Unarmed Strike Range: Self Components: V Duration: 1 minute 

The target takes an extra 1d6 Necrotic damage from the attack, and it must succeed on a Wisdom saving throw or have the Frightened condition until the spell ends. At the end of each of its turns, the Frightened target repeats the save, ending the spell on itself on a success. 

Using a Higher-Level Spell Slot. The damage increases by 1d6 for each spell slot level above 1


#Paladin
