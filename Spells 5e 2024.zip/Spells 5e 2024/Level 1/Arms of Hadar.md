level 1 - #conjuration Casting Time: Action Range: Self Components: V, S Duration: Instantaneous 

Invoking Hadar, you cause tendrils to erupt from yourself. Each creature in a 10-foot Emanation originating from you makes a Strength saving throw. On a failed save, a target takes 2d6 Necrotic damage and can't take Reactions until the start of its next turn. On a successful save, a target takes half as much damage only. 

Using a Higher-Level Spell Slot. The damage increases by 1d6 for each spell slot level above 1


#Warlock
