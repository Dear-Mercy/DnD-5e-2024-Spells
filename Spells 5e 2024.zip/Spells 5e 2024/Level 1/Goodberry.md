level 1 - #conjuration Casting Time: Action Range: Self Components: V, S, M (a sprig of mistletoe) Duration: 24 hours 

Ten berries appear in your hand and are infused with magic for the duration. A creature can take a Bonus Action to eat one berry. Eating a berry restores 1 Hit Point, and the berry provides enough nourishment to sustain a creature for one day. 
Uneaten berries disappear when the spell ends.


#Druid #Ranger
