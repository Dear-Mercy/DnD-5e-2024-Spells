level 1 - #evocation Casting Time: Action Range: 120 feet Components: V, S Duration: Instantaneous 

You create three glowing darts of magical force. Each dart strikes a creature of your choice that you can see within range. A dart deals 1d4 + 1 Force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several. 

Using a Higher-Level Spell Slot. The spell creates one more dart for each spell slot level above 1.


#Sorcerer #Wizard
