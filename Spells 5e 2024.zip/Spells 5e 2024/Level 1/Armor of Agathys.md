level 1 - #abjuration Casting Time: #BonusAction Range: Self Components: V, S, M (a shard of blue glass) Duration: 1 hour 

Protective magical frost surrounds you. You gain 5 Temporary Hit Points. If a creature hits you with a melee attack roll before the spell ends, the creature takes 5 Cold damage. The spell ends early if you have no Temporary Hit Points. 
Using a Higher-Level Spell Slot. The Temporary Hit Points and the Cold damage both increase by 5 for cach spell slot level above 1.


#Warlock
