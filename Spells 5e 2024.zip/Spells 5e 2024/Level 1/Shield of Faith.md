level 1 - #abjuration Casting Time: #BonusAction Range: 60 feet Components: V, S, M (a prayer scroll) Duration: #Concentration, up to 10 minutes 

A shimmering field surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration


#Cleric #Paladin
