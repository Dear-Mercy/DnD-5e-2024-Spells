level 1 - #necromancy Casting Time: Action Range: Touch Components: V, S Duration: Instantaneous 

A creature you touch makes a Constitution saving throw, taking 2d10 Necrotic damage on a failed save or half as much damage on a successful one. 

Using a Higher-Level Spell Slot. The damage increases by 1d10 for each spell slot level above 1.


#Cleric
