level 1 - #transmutation ( #ritual ) Casting Time: Action or Ritual Range: 10 feet Components: V, S Duration: Instantaneous 

You remove poison and rot from nonmagical food and drink in a 5- foot-radius Sphere centered on a point within range


#Cleric #Druid #Paladin
