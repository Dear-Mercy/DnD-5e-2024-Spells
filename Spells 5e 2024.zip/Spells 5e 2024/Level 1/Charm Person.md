level 1 - #enchantment Casting Time: Action Range: 30 feet Components: V, S Duration: 1 hour 

One Humanoid you can see within range makes a Wisdom saving throw. It does so with Advantage if you or your allies are fighting it. On a failed save, the target has the Charmed condition until the spell ends or until you or your allies damage it. The Charmed creature is Friendly to you. When the spell ends, the target knows it was Charmed by you. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 1.


#Bard #Druid #Sorcerer #Warlock #Wizard
