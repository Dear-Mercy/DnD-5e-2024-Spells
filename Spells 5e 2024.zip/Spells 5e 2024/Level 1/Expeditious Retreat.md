level 1 - #transmutation Casting Time: #BonusAction Range: Self Components: V, S Duration: #Concentration, up to 10 minutes 

You take the Dash action, and until the spell ends, you can take that action again as a Bonus Action


#Sorcerer #Warlock #Wizard
