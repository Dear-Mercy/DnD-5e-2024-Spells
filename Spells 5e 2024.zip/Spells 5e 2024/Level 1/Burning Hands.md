level 1 - #evocation Casting Time: Action Range: Self Components: V, S Duration: Instantaneous 

A thin sheet of flames shoots forth from you. Each creature in a 15- #foot Cone makes a Dexterity saving throw, taking 3d6 Fire damage on a failed save or half as much damage on a successful one. Flammable objects in the Cone that aren't being worn or carried start burning. 

Using a Higher-Level Spell Slot. The damage increases by 1d6 for each spell slot level above 1


#Sorcerer #Wizard
