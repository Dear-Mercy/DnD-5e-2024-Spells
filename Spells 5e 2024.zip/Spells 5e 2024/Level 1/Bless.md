level 1 - #enchantment Casting Time: Action Range: 30 feet Components: V, S, M (a Holy Symbol, worth 5+ GP) Duration: #Concentration, up to 1 minute 

You bless up to three creatures within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target adds 1d4 to the attack roll or save. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 1


#Cleric #Paladin
