level 1 - #transmutation Casting Time: #BonusAction Range: Touch Components: V, S, M (a grasshopper's hind leg) Duration: 1 minute 

You touch a willing creature. Once on each of its turns until the spell ends, that creature can jump up to 30 feet by spending 10 feet of movement. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 1


#Druid #Ranger #Sorcerer #Wizard
