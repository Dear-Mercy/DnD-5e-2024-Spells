level 1 - #abjuration Casting Time: #BonusAction Range: 60 feet Components: V Duration: Instantaneous 

A creature of your choice that you can see within range regains Hit Points equal to 2d4 plus your spellcasting ability modifier. 

Using a Higher-Level Spell Slot. The healing increases by 2d4 for each spell slot level above 1.


#Bard #Cleric #Druid
