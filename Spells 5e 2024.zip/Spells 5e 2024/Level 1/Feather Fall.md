level 1 - #transmutation Casting Time: #Reaction, which you take when you or a creature you can see within 60 feet of you falls Range: 60 feet Components: V, M (a small feather or piece of down) Duration: 1 minute 

Choose up to five falling creatures within range. A falling creature's rate of descent slows to 60 feet per round until the spell ends. If a creature lands before the spell ends, the creature takes no damage from the fall, and the spell ends for that creature.


#Bard #Sorcerer #Wizard
