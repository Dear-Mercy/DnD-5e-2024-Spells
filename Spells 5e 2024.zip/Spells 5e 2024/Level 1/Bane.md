level 1 - #enchantment Casting Time: Action Range: 30 feet Components: V, S, M (a drop of blood) Duration: #Concentration, up to 1 minute 

Up to three creatures of your choice that you can see within range must each make a Charisma saving throw. Whenever a target that fails this save makes an attack roll or a saving throw before the spell ends, the target must subtract 1d4 from the attack roll or save. 
Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 1.


#Bard #Cleric #Warlock
