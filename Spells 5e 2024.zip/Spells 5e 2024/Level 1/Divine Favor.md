level 1 - #transmutation Casting Time: #BonusAction Range: Self Components: V, S Duration: 1 minute 

Until the spell ends, your attacks with weapons deal an extra 1d4 Radiant damage on a hit


#Paladin
