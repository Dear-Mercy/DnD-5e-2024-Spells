level 1 - #divination ( #ritual ) Casting Time: Action or Ritual Range: Self Components: V, S Duration: 10 minutes 

For the duration, you can comprehend and verbally communicate with Beasts, and you can use any of the Influence action's skill options with them. 
Most Beasts have little to say about topics that don't pertain to survival or companionship, but at minimum, a Beast can give you information about nearby locations and monsters, including whatever it has perceived within the past day.


#Bard #Druid #Ranger #Warlock
