level 1 - #illusion Casting Time: Action Range: Self Components: V, S, M (a pinch of colorful sand) Duration: Instantaneous 

You launch a dazzling array of flashing, colorful light. Each creature in a 15-foot Cone originating from you must succeed on a Constitution saving throw or have the Blinded condition until the end of your next turn.


#Bard #Sorcerer #Wizard
