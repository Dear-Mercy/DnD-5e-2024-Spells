level 1 - #divination ( #ritual ) Casting Time: Action or Ritual Range: Self Components: V, S Duration: #Concentration, up to 10 minutes 

For the duration, you sense the presence of magical effects within 30 feet of yourself. If you sense such effects, you can take the Magic action to see a faint aura around any visible creature or object in the area that bears the magic, and if an effect was created by a spell, you learn the spell's school of magic.
The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead


#Bard #Cleric #Druid #Paladin #Ranger #Sorcerer #Warlock #Wizard
