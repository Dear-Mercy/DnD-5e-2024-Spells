level 1 - #divination Casting Time: Action Range: Self Components: V, S Duration: #Concentration, up to 10 minutes 

For the duration, you sense the location of any Aberration, Celestial, Elemental, Fey, Fiend, or Undead within 30 feet of yourself. You also sense whether the Hallow spell is active there and, if so, where. 
The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.


#Cleric #Paladin
