level 1 - #evocation Casting Time: #Reaction, which you take in response to taking damage from a creature that you can see within 60 feet of yourself Range: 60 feet Components: V, S Duration: Instantaneous 

The creature that damaged you is momentarily surrounded by green flames. It makes a Dexterity saving throw, taking 2d10 Fire damage on a failed save or half as much damage on a successful one. 

Using a Higher-Level Spell Slot. The damage increases by 1d10 for each spell slot level above 1.


#Warlock
