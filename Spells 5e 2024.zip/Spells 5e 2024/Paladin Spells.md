|   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
|[[Aid]]|2|abjuration|Action|30 ft|8 hours|V,S,M|||
|[[Aura of Life]]|4|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Aura of Purity]]|4|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Aura of Vitality]]|3|abjuration|Action|Self|1 minute|V|Concentration|   |
|[[Banishing Smite]]|5|conjuration|Bonus Action|Self|1 minute|V|Concentration|   |
|[[Banishment]]|4|abjuration|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Bless]]|1|enchantment|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Blinding Smite]]|3|evocation|Bonus Action|Self|1 minute|V|||
|[[Circle of Power]]|5|abjuration|Action|Self|10 minutes|V|Concentration|   |
|[[Command]]|1|enchantment|Action|60 ft|Instantaneous|V|||
|[[Compelled Duel]]|1|enchantment|Bonus Action|30 ft|1 minute|V|Concentration|   |
|[[Create Food and Water]]|3|conjuration|Action|30 ft|Instantaneous|V,S|||
|[[Crusader's Mantle]]|3|evocation|Action|Self|1 minute|V|Concentration|   |
|[[Cure Wounds]]|1|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Daylight]]|3|evocation|Action|60 ft|1 hour|V,S|||
|[[Death Ward]]|4|abjuration|Action|Touch|8 hours|V,S|||
|[[Destructive Wave]]|5|evocation|Action|Self|Instantaneous|V|||
|[[Detect Evil and Good]]|1|divination|Action|Self|10 minutes|V,S|Concentration|   |
|[[Detect Magic]]|1|divination|Action or Ritual|Self|10 minutes|V,S|Concentration|Ritual|
|[[Detect Poison and Disease]]|1|divination|Action or Ritual|Self|10 minutes|V,S,M|Concentration|Ritual|
|[[Dispel Evil and Good]]|5|abjuration|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Dispel Magic]]|3|abjuration|Action|120 ft|Instantaneous|V,S|||
|[[Divine Favor]]|1|transmutation|Bonus Action|Self|1 minute|V,S|||
|[[Divine Smite]]|1|evocation|Bonus Action|Self|Instantaneous|V|||
|[[Elemental Weapon]]|3|transmutation|Action|Touch|1 hour|V,S|Concentration|   |
|[[Find Steed]]|2|conjuration|Action|30 ft|Instantaneous|V,S|||
|[[Geas]]|5|enchantment|1 minute|60 ft|30 days|V|||
|[[Gentle Repose]]|2|necromancy|Action or Ritual|Touch|10 days|V,S,M||Ritual|
|[[Greater Restoration]]|5|abjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Heroism]]|1|enchantment|Action|Touch|1 minute|V,S|Concentration|   |
|[[Lesser Restoration]]|2|abjuration|Bonus Action|Touch|Instantaneous|V,S|||
|[[Locate Creature]]|4|divination|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Locate Object]]|2|divination|Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Magic Circle]]|3|abjuration|1 minute|10 ft|1 hour|V,S,M|||
|[[Magic Weapon]]|2|transmutation|Bonus Action|Touch|1 hour|V,S|||
|[[Prayer of Healing]]|2|abjuration|10 minutes|30 ft|Instantaneous|V|||
|[[Protection from Evil and Good]]|1|abjuration|Action|Touch|10 minutes|V,S,M|Concentration|   |
|[[Protection from Poison]]|2|abjuration|Action|Touch|1 hour|V,S|||
|[[Purify Food and Drink]]|1|transmutation|Action or Ritual|10 ft|Instantaneous|V,S||Ritual|
|[[Raise Dead]]|5|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[Remove Curse]]|3|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Revivify]]|3|necromancy|Action|Touch|Instantaneous|V,S,M|||
|[[Searing Smite]]|1|evocation|Bonus Action|Self|1 minute|V|||
|[[Shield of Faith]]|1|abjuration|Bonus Action|60 ft|10 minutes|V,S,M|Concentration|   |
|[[Shining Smite]]|2|transmutation|Bonus Action|Self|1 minute|V|Concentration|   |
|[[Staggering Smite]]|4|enchantment|Bonus Action|Self|Instantaneous|V|||
|[[Summon Celestial]]|5|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Thunderous Smite]]|1|evocation|Bonus Action|Self|Instantaneous|V|||
|[[Warding Bond]]|2|abjuration|Action|Touch|1 hour|V,S,M|||
|[[Wrathful Smite]]|1|necromancy|Bonus Action|Self|1 minute|V|||
|[[Zone of Truth]]|2|enchantment|Action|60 ft|10 minutes|V,S|||