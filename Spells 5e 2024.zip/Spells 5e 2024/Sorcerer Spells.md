|                               |     |               |                  |        |               |       |               |
| ----------------------------- | --- | ------------- | ---------------- | ------ | ------------- | ----- | ------------- |
| [[Acid Splash]]               | 0   | evocation     | Action           | 60 ft  | Instantaneous | V,S   |               |
| [[Alter Self]]                | 2   | transmutation | Action           | Self   | 1 hour        | V,S   | Concentration |
| [[Animate Objects]]           | 5   | transmutation | Action           | 120 ft | 1 minute      | V,S   | Concentration |
| [[Arcane Gate]]               | 6   | conjuration   | Action           | 500 ft | 10 minutes    | V,S   | Concentration |
| [[Arcane Vigor]]              | 2   | abjuration    | Bonus Action     | Self   | Instantaneous | V,S   |               |
| [[Banishment]]                | 4   | abjuration    | Action           | 30 ft  | 1 minute      | V,S,M | Concentration |
| [[Bigby's Hand]]              | 5   | evocation     | Action           | 120 ft | 1 minute      | V,S,M | Concentration |
| [[Blade Ward]]                | 0   | abjuration    | Action           | Self   | 1 minute      | V,S   | Concentration |
| [[Blight]]                    | 4   | necromancy    | Action           | 30 ft  | Instantaneous | V,S   |               |
| [[Blindness Deafness]]        | 2   | transmutation | Action           | 120 ft | 1 minute      | V     |               |
| [[Blink]]                     | 3   | transmutation | Action           | Self   | 1 minute      | V,S   |               |
| [[Blur]]                      | 2   | illusion      | Action           | Self   | 1 minute      | V     | Concentration |
| [[Burning Hands]]             | 1   | evocation     | Action           | Self   | Instantaneous | V,S   |               |
| [[Chain Lightning]]           | 6   | evocation     | Action           | 150 ft | Instantaneous | V,S,M |               |
| [[Charm Monster]]             | 4   | enchantment   | Action           | 30 ft  | 1 hour        | V,S   |               |
| [[Charm Person]]              | 1   | enchantment   | Action           | 30 ft  | 1 hour        | V,S   |               |
| [[Chill Touch]]               | 0   | necromancy    | Action           | Touch  | Instantaneous | V,S   |               |
| [[Chromatic Orb]]             | 1   | evocation     | Action           | 90 ft  | Instantaneous | V,S,M |               |
| [[Circle of Death]]           | 6   | necromancy    | Action           | 150 ft | Instantaneous | V,S,M |               |
| [[Clairvoyance]]              | 3   | divination    | 10 minutes       | 1 mile | 10 minutes    | V,S,M | Concentration |
| [[Cloud of Daggers]]          | 2   | conjuration   | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Cloudkill]]                 | 5   | conjuration   | Action           | 120 ft | 10 minutes    | V,S   | Concentration |
| [[Color Spray]]               | 1   | illusion      | Action           | Self   | Instantaneous | V,S,M |               |
| [[Comprehend Languages]]      | 1   | divination    | Action or Ritual | Self   | 1 hour        | V,S,M |               |
| [[Cone of Cold]]              | 5   | evocation     | Action           | Self   | Instantaneous | V,S,M |               |
| [[Confusion]]                 | 4   | enchantment   | Action           | 90 ft  | 1 minute      | V,S,M | Concentration |
| [[Counterspell]]              | 3   | abjuration    | Reaction         | 60 ft  | Instantaneous | S     |               |
| [[Creation]]                  | 5   | illusion      | 1 minute         | 30 ft  | Special       | V,S,M |               |
| [[Crown of Madness]]          | 2   | enchantment   | Action           | 120 ft | 1 minute      | V,S   | Concentration |
| [[Dancing Lights]]            | 0   | illusion      | Action           | 120 ft | 1 minute      | V,S,M | Concentration |
| [[Darkness]]                  | 2   | evocation     | Action           | 60 ft  | 10 minutes    | V,M   | Concentration |
| [[Darkvision]]                | 2   | transmutation | Action           | Touch  | 8 hours       | V,S,M |               |
| [[Daylight]]                  | 3   | evocation     | Action           | 60 ft  | 1 hour        | V,S   |               |
| [[Delayed Blast Fireball]]    | 7   | evocation     | Action           | 150 ft | 1 minute      | V,S,M | Concentration |
| [[Demiplane]]                 | 8   | conjuration   | Action           | 60 ft  | 1 hour        | S     |               |
| [[Detect Magic]]              | 1   | divination    | Action or Ritual | Self   | 10 minutes    | V,S   | Concentration |
| [[Detect Thoughts]]           | 2   | divination    | Action           | Self   | 1 minute      | V,S,M | Concentration |
| [[Dimension Door]]            | 4   | conjuration   | Action           | 500 ft | Instantaneous | V     |               |
| [[Disguise Self]]             | 1   | illusion      | Action           | Self   | 1 hour        | V,S   |               |
| [[Disintegrate]]              | 6   | transmutation | Action           | 60 ft  | Instantaneous | V,S,M |               |
| [[Dispel Magic]]              | 3   | abjuration    | Action           | 120 ft | Instantaneous | V,S   |               |
| [[Dominate Beast]]            | 4   | enchantment   | Action           | 60 ft  | 1 minute      | V,S   | Concentration |
| [[Dominate Monster]]          | 8   | enchantment   | Action           | 60 ft  | 1 hour        | V,S   | Concentration |
| [[Dominate Person]]           | 5   | enchantment   | Action           | 60 ft  | 1 minute      | V,S   | Concentration |
| [[Dragon's Breath]]           | 2   | transmutation | Bonus Action     | Touch  | 1 minute      | V,S,M | Concentration |
| [[Earthquake]]                | 8   | transmutation | Action           | 500 ft | 1 minute      | V,S,M | Concentration |
| [[Elementalism]]              | 0   | transmutation | Action           | 30 ft  | Instantaneous | V,S   |               |
| [[Enhance Ability]]           | 2   | transmutation | Action           | Touch  | 1 hour        | V,S,M | Concentration |
| [[Enlarge Reduce]]            | 2   | transmutation | Action           | 30 ft  | 1 minute      | V,S,M | Concentration |
| [[Etherealness]]              | 7   | conjuration   | Action           | Self   | 8 hours       | V,S   |               |
| [[Expeditious Retreat]]       | 1   | transmutation | Bonus Action     | Self   | 10 minutes    | V,S   | Concentration |
| [[Eyebite]]                   | 6   | necromancy    | Action           | Self   | 1 minute      | V,S   | Concentration |
| [[False Life]]                | 1   | necromancy    | Action           | Self   | Instantaneous | V,S,M |               |
| [[Fear]]                      | 3   | illusion      | Action           | Self   | 1 minute      | V,S,M | Concentration |
| [[Feather Fall]]              | 1   | transmutation | Reaction         | 60 ft  | 1 minute      | V,M   |               |
| [[Finger of Death]]           | 7   | necromancy    | Action           | 60 ft  | Instantaneous | V,S   |               |
| [[Fire Bolt]]                 | 0   | evocation     | Action           | 120 ft | Instantaneous | V,S   |               |
| [[Fire Shield]]               | 4   | evocation     | Action           | Self   | 10 minutes    | V,S,M |               |
| [[Fire Storm]]                | 7   | evocation     | Action           | 150 ft | Instantaneous | V,S   |               |
| [[Fireball]]                  | 3   | evocation     | Action           | 150 ft | Instantaneous | V,S,M |               |
| [[Flame Blade]]               | 2   | evocation     | Bonus Action     | Self   | 10 minutes    | V,S,M | Concentration |
| [[Flaming Sphere]]            | 2   | conjuration   | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Flesh to Stone]]            | 6   | transmutation | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Fly]]                       | 3   | transmutation | Action           | Touch  | 10 minutes    | V,S,M | Concentration |
| [[Fog Cloud]]                 | 1   | conjuration   | Action           | 120 ft | 1 hour        | V,S   | Concentration |
| [[Friends]]                   | 0   | enchantment   | Action           | 10 ft  | 1 minute      | S,M   | Concentration |
| [[Gaseous Form]]              | 3   | transmutation | Action           | Touch  | 1 hour        | V,S,M | Concentration |
| [[Gate]]                      | 9   | conjuration   | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Globe of Invulnerability]]  | 6   | abjuration    | Action           | Self   | 1 minute      | V,S,M | Concentration |
| [[Grease]]                    | 1   | conjuration   | Action           | 60 ft  | 1 minute      | V,S,M |               |
| [[Greater Invisibility]]      | 4   | illusion      | Action           | Touch  | 1 minute      | V,S   | Concentration |
| [[Gust of Wind]]              | 2   | evocation     | Action           | Self   | 1 minute      | V,S,M | Concentration |
| [[Haste]]                     | 3   | transmutation | Action           | 30 ft  | 1 minute      | V,S,M | Concentration |
| [[Hold Monster]]              | 5   | enchantment   | Action           | 90 ft  | 1 minute      | V,S,M | Concentration |
| [[Hold Person]]               | 2   | enchantment   | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Hypnotic Pattern]]          | 3   | illusion      | Action           | 120 ft | 1 minute      | S,M   | Concentration |
| [[Ice Knife]]                 | 1   | conjuration   | Action           | 60 ft  | Instantaneous | S,M   |               |
| [[Ice Storm]]                 | 4   | evocation     | Action           | 300 ft | Instantaneous | V,S,M |               |
| [[Incendiary CLoud]]          | 8   | conjuration   | Action           | 150 ft | 1 minute      | V,S   | Concentration |
| [[Insect Plague]]             | 5   | conjuration   | Action           | 300 ft | 10 minutes    | V,S,M | Concentration |
| [[Invisibility]]              | 2   | illusion      | Action           | Touch  | 1 hour        | V,S,M | Concentration |
| [[Jump]]                      | 1   | transmutation | Bonus Action     | Touch  | 1 minute      | V,S,M |               |
| [[Knock]]                     | 2   | transmutation | Action           | 60 ft  | Instantaneous | V     |               |
| [[Levitate]]                  | 2   | transmutation | Action           | 60 ft  | 10 minutes    | V,S,M | Concentration |
| [[Light]]                     | 0   | evocation     | Action           | Touch  | 1 hour        | V,M   |               |
| [[Lightning Bolt]]            | 3   | evocation     | Action           | Self   | Instantaneous | V,S,M |               |
| [[Mage Armor]]                | 1   | abjuration    | Action           | Touch  | 8 hours       | V,S,M |               |
| [[Mage Hand]]                 | 0   | conjuration   | Action           | 30 ft  | 1 minute      | V,S   |               |
| [[Magic Missile]]             | 1   | evocation     | Action           | 120 ft | Instantaneous | V,S   |               |
| [[Magic Weapon]]              | 2   | transmutation | Bonus Action     | Touch  | 1 hour        | V,S   |               |
| [[Major Image]]               | 3   | illusion      | Action           | 120 ft | 10 minutes    | V,S,M | Concentration |
| [[Mass Suggestion]]           | 6   | enchantment   | Action           | 60 ft  | 24 hours      | V,M   |               |
| [[Mending]]                   | 0   | transmutation | 1 minute         | Touch  | Instantaneous | V,S,M |               |
| [[Message]]                   | 0   | transmutation | Action           | 120 ft | 1 round       | S,M   |               |
| [[Meteor Swarm]]              | 9   | evocation     | Action           | 1 mile | Instantaneous | V,S   |               |
| [[Mind Sliver]]               | 0   | enchantment   | Action           | 60 ft  | 1 round       | V     |               |
| [[Mind Spike]]                | 2   | divination    | Action           | 120 ft | 1 hour        | S     | Concentration |
| [[Minor Illusion]]            | 0   | illusion      | Action           | 30 ft  | 1 minute      | S,M   |               |
| [[Mirror Image]]              | 2   | illusion      | Action           | Self   | 1 minute      | V,S   |               |
| [[Misty Step]]                | 2   | conjuration   | Bonus Action     | Self   | Instantaneous | V     |               |
| [[Move Earth]]                | 6   | transmutation | Action           | 120 ft | 2 hours       | V,S,M | Concentration |
| [[Otiluke's Freezing Sphere]] | 6   | evocation     | Action           | 300 ft | Instantaneous | V,S,M |               |
| [[Phantasmal Force]]          | 2   | illusion      | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Plane Shift]]               | 7   | conjuration   | Action           | Touch  | Instantaneous | V,S,M |               |
| [[Poison Spray]]              | 0   | necromancy    | Action           | 30 ft  | Instantaneous | V,S   |               |
| [[Polymorph]]                 | 4   | transmutation | Action           | 60 ft  | 1 hour        | V,S,M | Concentration |
| [[Power Word Kill]]           | 9   | enchantment   | Action           | 60 ft  | Instantaneous | V     |               |
| [[Power Word Stun]]           | 8   | enchantment   | Action           | 60 ft  | Instantaneous | V     |               |
| [[Prestidigitation]]          | 0   | transmutation | Action           | 10 ft  | 1 hour        | V,S   |               |
| [[Prismatic Spray]]           | 7   | evocation     | Action           | Self   | Instantaneous | V,S   |               |
| [[Protection from Energy]]    | 3   | abjuration    | Action           | Touch  | 1 hour        | V,S   | Concentration |
| [[Ray of Frost]]              | 0   | evocation     | Action           | 60 ft  | Instantaneous | V,S   |               |
| [[Ray of Sickness]]           | 1   | necromancy    | Action           | 60 ft  | Instantaneous | V,S   |               |
| [[Reverse Gravity]]           | 7   | transmutation | Action           | 100 ft | 1 minute      | V,S,M | Concentration |
| [[Scorching Ray]]             | 2   | evocation     | Action           | 120 ft | Instantaneous | V,S   |               |
| [[See Invisibility]]          | 2   | divination    | Action           | Self   | 1 hour        | V,S,M |               |
| [[Seeming]]                   | 5   | illusion      | Action           | 30 ft  | 8 hours       | V,S   |               |
| [[Shatter]]                   | 2   | evocation     | Action           | 60 ft  | Instantaneous | V,S,M |               |
| [[Shield]]                    | 1   | abjuration    | Reaction         | Self   | 1 round       | V,S   |               |
| [[Shocking Grasp]]            | 0   | evocation     | Action           | Touch  | Instantaneous | V,S   |               |
| [[Silent Image]]              | 1   | illusion      | Action           | 60 ft  | 10 minutes    | V,S,M | Concentration |
| [[Sleep]]                     | 1   | enchantment   | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |
| [[Sleet Storm]]               | 3   | conjuration   | Action           | 150 ft | 1 minute      | V,S,M | Concentration |
| [[Slow]]                      | 3   | transmutation | Action           | 120 ft | 1 minute      | V,S,M | Concentration |
| [[Sorcerous Burst]]           | 0   | evocation     | Action           | 120 ft | Instantaneous | V,S   |               |
| [[Spider Climb]]              | 2   | transmutation | Action           | Touch  | 1 hour        | V,S,M | Concentration |
| [[Stinking Cloud]]            | 3   | conjuration   | Action           | 90 ft  | 1 minute      | V,S,M | Concentration |
| [[Stoneskin]]                 | 4   | transmutation | Action           | Touch  | 1 hour        | V,S,M | Concentration |
| [[Suggestion]]                | 2   | enchantment   | Action           | 30 ft  | 8 hours       | V,M   | Concentration |
| [[Sunbeam]]                   | 6   | evocation     | Action           | Self   | 1 minute      | V,S,M | Concentration |
| [[Sunburst]]                  | 8   | evocation     | Action           | 150 ft | Instantaneous | V,S,M |               |
| [[Synaptic Static]]           | 5   | enchantment   | Action           | 120 ft | Instantaneous | V,S   |               |
| [[Telekinesis]]               | 5   | transmutation | Action           | 60 ft  | 10 minutes    | V,S   | Concentration |
| [[Teleport]]                  | 7   | conjuration   | Action           | 10 ft  | Instantaneous | V     |               |
| [[Teleportation Circle]]      | 5   | conjuration   | 1 minute         | 10 ft  | 1 round       | V,M   |               |
| [[Thunderclap]]               | 0   | evocation     | Action           | Self   | Instantaneous | S     |               |
| [[Thunderwave]]               | 1   | evocation     | Action           | Self   | Instantaneous | V,S   |               |
| [[Time Stop]]                 | 9   | transmutation | Action           | Self   | Instantaneous | V     |               |
| [[Tongues]]                   | 3   | divination    | Action           | Touch  | 1 hour        | V,M   |               |
| [[True Seeing]]               | 6   | divination    | Action           | Touch  | 1 hour        | V,S,M |               |
| [[True Strike]]               | 0   | divination    | Action           | Self   | Instantaneous | S,M   |               |
| [[Vampiric Touch]]            | 3   | necromancy    | Action           | Self   | 1 minute      | V,S   | Concentration |
| [[Vitriolic Sphere]]          | 4   | evocation     | Action           | 150 ft | Instantaneous | V,S,M |               |
| [[Wall of Fire]]              | 4   | evocation     | Action           | 120 ft | 1 minute      | V,S,M | Concentration |
| [[Wall of Stone]]             | 5   | evocation     | Action           | 120 ft | 10 minutes    | V,S,M | Concentration |
| [[Water Breathing]]           | 3   | transmutation | Action or Ritual | 30 ft  | 24 hours      | V,S,M |               |
| [[Water Walk]]                | 3   | transmutation | Action or Ritual | 30 ft  | 1 hour        | V,S,M |               |
| [[Web]]                       | 2   | conjuration   | Action           | 60 ft  | 1 hour        | V,S,M | Concentration |
| [[Wish]]                      | 9   | conjuration   | Action           | Self   | Instantaneous | V     |               |
| [[Witch Bolt]]                | 1   | evocation     | Action           | 60 ft  | 1 minute      | V,S,M | Concentration |