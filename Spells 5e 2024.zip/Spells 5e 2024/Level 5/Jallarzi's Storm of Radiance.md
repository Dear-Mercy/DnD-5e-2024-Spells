level 5 - #evocation Casting Time: Action Range: 120 feet Components: V, S, M (a pinch of phosphorus) Duration: #Concentration, up to 1 minute 

Description not available (not OGL)


#Warlock #Wizard
