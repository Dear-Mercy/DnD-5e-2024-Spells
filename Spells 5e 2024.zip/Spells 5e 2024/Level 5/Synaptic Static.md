level 5 - #enchantment Casting Time: Action Range: 120 feet Components: V, S Duration: Instantaneous 

Description not available (not OGL).


#Bard #Sorcerer #Warlock #Wizard
