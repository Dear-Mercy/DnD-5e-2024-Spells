level 5 - #abjuration Casting Time: Action Range: Self Components: V Duration: #Concentration, up to 10 minutes Description 

not available (not OGL)


#Cleric #Paladin #Wizard
