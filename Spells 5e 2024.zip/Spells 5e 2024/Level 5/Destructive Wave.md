level 5 - #evocation Casting Time: Action Range: Self Components: V Duration: Instantaneous 

Description not available (not OGL).


#Paladin
