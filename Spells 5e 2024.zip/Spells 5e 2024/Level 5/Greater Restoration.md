level 5 - #abjuration Casting Time: Action Range: Touch Components: V, S, M (diamond dust worth 100+ GP, which the spell consumes) Duration: Instantaneous 

You touch a creature and magically remove one of the following effects from it: 
• 1 Exhaustion level 
• The Charmed or Petrified condition 
• A curse, including the target's Attunement to a cursed magic item 
• Any reduction to one of the target's ability scores 
• Any reduction to the target's Hit Point maximum


#Bard #Cleric #Druid #Paladin #Ranger
