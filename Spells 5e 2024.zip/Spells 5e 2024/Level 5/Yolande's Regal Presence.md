level 5 - #enchantment Casting Time: Action Range: Self Components: V, S, M (a miniature tiara) Duration: #Concentration, up to 1 minute 

Description not available (not OGL)


#Bard #Wizard
