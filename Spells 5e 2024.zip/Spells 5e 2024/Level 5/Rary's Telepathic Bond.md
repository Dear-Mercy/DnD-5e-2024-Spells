level 5 - #divination ( #ritual ) Casting Time: Action or Ritual Range: 30 feet Components: V, S, M (two eggs) Duration: 1 hour 

Description not available (not OGL)


#Bard #Wizard
