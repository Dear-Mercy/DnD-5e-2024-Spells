level 5 - #enchantment Casting Time: Action Range: 90 feet Components: V, S, M (a straight piece of iron) Duration: #Concentration, up to 1 minute 

Choose a creature that you can see within range. The target must succeed on a Wisdom saving throw or have the Paralyzed condition for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 5.


#Bard #Sorcerer #Warlock #Wizard
