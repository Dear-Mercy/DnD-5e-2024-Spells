level 5 - #abjuration Casting Time: Action Range: Self Components: V, S Duration: #Concentration, up to 1 hour 

An aura extends from you in a 10-foot Emanation for the duration. The aura prevents creatures other than Constructs and Undead from passing or reaching through it. An affected creature can cast spells or make attacks with Ranged or Reach weapons through the barrier.
If you move so that an affected creature is forced to pass through the barrier, the spell ends.


#Druid
