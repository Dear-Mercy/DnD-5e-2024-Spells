level 5 - #transmutation Casting Time: #BonusAction Range: Self Components: V, S, M (a Quiver worth 1+ GP) Duration: #Concentration, up to 1 minute 

Description not available (not OGL)


#Ranger
