level 5 - #conjuration Casting Time: Action Range: 30 feet Components: S, M (a Melee weapon worth 1+ SP) Duration: Instantaneous 

Description not available (not OGL)


#Ranger #Wizard
