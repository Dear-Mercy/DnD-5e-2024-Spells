level 5 - #abjuration Casting Time: Action Range: 60 feet Components: V, S Duration: Instantaneous 

A wave of healing energy washes out from a point you can see within range. Choose up to six creatures in a 30-foot-radius Sphere centered on that point. Each target regains Hit Points equal to 5d8 plus your spellcasting ability modifier. 

Using a Higher-Level Spell Slot. The healing increases by 1d8 for each spell slot level above 5


#Bard #Cleric #Druid
