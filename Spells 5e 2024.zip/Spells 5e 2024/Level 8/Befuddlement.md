level 8 - #enchantment Casting Time: Action Range: 150 feet Components: V, S, M (a key ring with no keys) Duration: Instantaneous

Description not available (not OGL)


#Bard #Druid #Warlock #Wizard
