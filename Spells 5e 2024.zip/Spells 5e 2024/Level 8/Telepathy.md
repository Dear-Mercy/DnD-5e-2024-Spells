level 8 - #divination Casting Time: Action Range: Unlimited Components: V, S, M (a pair of linked silver rings) Duration: 24 hours 

Description not available (not OGL)


#Wizard
