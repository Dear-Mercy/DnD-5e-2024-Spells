level 8 - #evocation Casting Time: Action Range: 150 feet Components: V, S, M (piece of sunstone) Duration: Instantaneous 

Brilliant sunlight flashes in a 60-foot-radius Sphere centered on a point you choose within range. Each creature in the Sphere makes a Constitution saving throw. On a failed save, a creature takes 12d6 Radiant damage and has the Blinded condition for 1 minute. On a successful save, it takes half as much damage only.
A creature Blinded by this spell makes another Constitution saving throw at the end of each of its turns, ending the effect on itself on a success. 
This spell dispels Darkness in its area that was created by any spell.


#Cleric #Druid #Sorcerer #Wizard
