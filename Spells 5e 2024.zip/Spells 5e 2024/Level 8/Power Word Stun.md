level 8 - #enchantment Casting Time: Action Range: 60 feet Components: V Duration: Instantaneous 

You overwhelm the mind of one creature you can see within range. If the target has 150 Hit Points or fewer, it has the Stunned condition. Otherwise, its Speed is 0 until the start of your next turn. 
The Stunned target makes a Constitution saving throw at the end of each of its turns, ending the condition on itself on a success.


#Bard #Sorcerer #Warlock #Wizard
