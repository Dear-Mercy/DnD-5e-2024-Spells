|                                        |     |               |                                             |           |                        |       |               |        |
| -------------------------------------- | --- | ------------- | ------------------------------------------- | --------- | ---------------------- | ----- | ------------- | ------ |
| [[Aid]]                                | 2   | abjuration    | Action                                      | 30 ft     | 8 hours                | V,S,M |               |        |
| [[Animal Friendship]]                  | 1   | enchantment   | Action                                      | 30 ft     | 24 hours               | V,S,M |               |        |
| [[Animal Messenger]]                   | 2   | enchantment   | Action or Ritual                            | 30 ft     | 24 hours               | V,S,M |               | Ritual |
| [[Animate Objects]]                    | 5   | transmutation | Action                                      | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Antipathy Sympathy]]                 | 8   | enchantment   | 1 hour                                      | 60 ft     | 10 days                | V,S,M |               |        |
| [[Awaken]]                             | 5   | transmutation | 8 hours                                     | Touch     | Instantaneous          | V,S,M |               |        |
| [[Bane]]                               | 1   | enchantment   | Action                                      | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Befuddlement]]                       | 8   | enchantment   | Action                                      | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Bestow Curse]]                       | 3   | necromancy    | Action                                      | Touch     | 1 minute               | V,S   | Concentration |        |
| [[Blade Ward]]                         | 0   | abjuration    | Action                                      | Self      | 1 minute               | V,S   | Concentration |        |
| [[Blindness Deafness]]                 | 2   | transmutation | Action                                      | 120 ft    | 1 minute               | V     |               |        |
| [[Calm Emotions]]                      | 2   | enchantment   | Action                                      | 60 ft     | 1 minute               | V,S   | Concentration |        |
| [[Charm Monster]]                      | 4   | enchantment   | Action                                      | 30 ft     | 1 hour                 | V,S   |               |        |
| [[Charm Person]]                       | 1   | enchantment   | Action                                      | 30 ft     | 1 hour                 | V,S   |               |        |
| [[Clairvoyance]]                       | 3   | divination    | 10 minutes                                  | 1 mile    | 10 minutes             | V,S,M | Concentration |        |
| [[Cloud of Daggers]]                   | 2   | conjuration   | Action                                      | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Color Spray]]                        | 1   | illusion      | Action                                      | Self      | Instantaneous          | V,S,M |               |        |
| [[Command]]                            | 1   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Comprehend Languages]]               | 1   | divination    | Action or Ritual                            | Self      | 1 hour                 | V,S,M |               | Ritual |
| [[Compulsion]]                         | 4   | enchantment   | Action                                      | 30 ft     | 1 minute               | V,S   | Concentration |        |
| [[Confusion]]                          | 4   | enchantment   | Action                                      | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Crown of Madness]]                   | 2   | enchantment   | Action                                      | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Cure Wounds]]                        | 1   | abjuration    | Action                                      | Touch     | Instantaneous          | V,S   |               |        |
| [[Dancing Lights]]                     | 0   | illusion      | Action                                      | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Detect Magic]]                       | 1   | divination    | Action or Ritual                            | Self      | 10 minutes             | V,S   | Concentration | Ritual |
| [[Detect Thoughts]]                    | 2   | divination    | Action                                      | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Dimension Door]]                     | 4   | conjuration   | Action                                      | 500 ft    | Instantaneous          | V     |               |        |
| [[Disguise Self]]                      | 1   | illusion      | Action                                      | Self      | 1 hour                 | V,S   |               |        |
| [[Dispel Magic]]                       | 3   | abjuration    | Action                                      | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Dissonant Whispers]]                 | 1   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Dominate Monster]]                   | 8   | enchantment   | Action                                      | 60 ft     | 1 hour                 | V,S   | Concentration |        |
| [[Dominate Person]]                    | 5   | enchantment   | Action                                      | 60 ft     | 1 minute               | V,S   | Concentration |        |
| [[Dream]]                              | 5   | illusion      | 1 minute                                    | Special   | 8 hours                | V,S,M |               |        |
| [[Enhance Ability]]                    | 2   | transmutation | Action                                      | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Enlarge Reduce]]                     | 2   | transmutation | Action                                      | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Enthrall]]                           | 2   | enchantment   | Action                                      | 60 ft     | 1 minute               | V,S   | Concentration |        |
| [[Etherealness]]                       | 7   | conjuration   | Action                                      | Self      | 8 hours                | V,S   |               |        |
| [[Eyebite]]                            | 6   | necromancy    | Action                                      | Self      | 1 minute               | V,S   | Concentration |        |
| [[Faerie Fire]]                        | 1   | evocation     | Action                                      | 60 ft     | 1 minute               | V     | Concentration |        |
| [[Fear]]                               | 3   | illusion      | Action                                      | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Feather Fall]]                       | 1   | transmutation | Reaction                                    | 60 ft     | 1 minute               | V,M   |               |        |
| [[Feign Death]]                        | 3   | necromancy    | Action or Ritual                            | Touch     | 1 hour                 | V,S,M |               | Ritual |
| [[Find the Path]]                      | 6   | divination    | 1 minute                                    | Self      | 1 day                  | V,S,M | Concentration |        |
| [[Forcecage]]                          | 7   | evocation     | Action                                      | 100 ft    | 1 hour                 | V,S,M |               |        |
| [[Foresight]]                          | 9   | divination    | 1 minute                                    | Touch     | 8 hours                | V,S,M |               |        |
| [[Fount of Moonlight]]                 | 4   | evocation     | Action                                      | Self      | 10 minutes             | V,S   | Concentration |        |
| [[Freedom of Movement]]                | 4   | abjuration    | Action                                      | Touch     | 1 hour                 | V,S,M |               |        |
| [[Friends]]                            | 0   | enchantment   | Action                                      | 10 ft     | 1 minute               | S,M   | Concentration |        |
| [[Geas]]                               | 5   | enchantment   | 1 minute                                    | 60 ft     | 30 days                | V     |               |        |
| [[Glibness]]                           | 8   | enchantment   | Action                                      | Self      | 1 hour                 | V     |               |        |
| [[Glyph of Warding]]                   | 3   | abjuration    | 1 hour                                      | Touch     | Dispelled or triggered | V,S,M |               |        |
| [[Greater Invisibility]]               | 4   | illusion      | Action                                      | Touch     | 1 minute               | V,S   | Concentration |        |
| [[Greater Restoration]]                | 5   | abjuration    | Action                                      | Touch     | Instantaneous          | V,S,M |               |        |
| [[Guards and Wards]]                   | 6   | abjuration    | 1 hour                                      | Touch     | 24 hours               | V,S,M |               |        |
| [[Hallucinatory Terrain]]              | 4   | illusion      | 10 minutes                                  | 300 ft    | 24 hours               | V,S,M |               |        |
| [[Healing Word]]                       | 1   | abjuration    | Bonus Action                                | 60 ft     | Instantaneous          | V     |               |        |
| [[Heat Metal]]                         | 2   | transmutation | Action                                      | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Heroes' Feast]]                      | 6   | conjuration   | 10 minutes                                  | Self      | Instantaneous          | V,S,M |               |        |
| [[Heroism]]                            | 1   | enchantment   | Action                                      | Touch     | 1 minute               | V,S   | Concentration |        |
| [[Hold Monster]]                       | 5   | enchantment   | Action                                      | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Hold Person]]                        | 2   | enchantment   | Action                                      | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Hypnotic Pattern]]                   | 3   | illusion      | Action                                      | 120 ft    | 1 minute               | S,M   | Concentration |        |
| [[Identify]]                           | 1   | divination    | 1 minute or Ritual                          | Touch     | Instantaneous          | V,S,M |               | Ritual |
| [[Illusory Script]]                    | 1   | illusion      | 1 minute or Ritual                          | Touch     | 10 days                | S,M   |               | Ritual |
| [[Invisibility]]                       | 2   | illusion      | Action                                      | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Knock]]                              | 2   | transmutation | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Legend Lore]]                        | 5   | divination    | 10 minutes                                  | Self      | Instantaneous          | V,S,M |               |        |
| [[Leomund's Tiny Hut]]                 | 3   | evocation     | 1 minute or Ritual                          | Self      | 8 hours                | V,S,M |               | Ritual |
| [[Lesser Restoration]]                 | 2   | abjuration    | Bonus Action                                | Touch     | Instantaneous          | V,S   |               |        |
| [[Light]]                              | 0   | evocation     | Action                                      | Touch     | 1 hour                 | V,M   |               |        |
| [[Locate Animals or Plants]]           | 2   | divination    | Action or Ritual                            | Self      | Instantaneous          | V,S,M |               | Ritual |
| [[Locate Creature]]                    | 4   | divination    | Action                                      | Self      | 1 hour                 | V,S,M | Concentration |        |
| [[Locate Object]]                      | 2   | divination    | Action                                      | Self      | 10 minutes             | V,S,M | Concentration |        |
| [[Longstrider]]                        | 1   | transmutation | Action                                      | Touch     | 1 hour                 | V,S,M |               |        |
| [[Mage Hand]]                          | 0   | conjuration   | Action                                      | 30 ft     | 1 minute               | V,S   |               |        |
| [[Magic Mouth]]                        | 2   | illusion      | 1 minute or Ritual                          | 30 ft     | Dispelled              | V,S,M |               | Ritual |
| [[Major Image]]                        | 3   | illusion      | Action                                      | 120 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Mass Cure Wounds]]                   | 5   | abjuration    | Action                                      | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Mass Healing Word]]                  | 3   | abjuration    | Bonus Action                                | 60 ft     | Instantaneous          | V     |               |        |
| [[Mass Suggestion]]                    | 6   | enchantment   | Action                                      | 60 ft     | 24 hours               | V,M   |               |        |
| [[Mending]]                            | 0   | transmutation | 1 minute                                    | Touch     | Instantaneous          | V,S,M |               |        |
| [[Message]]                            | 0   | transmutation | Action                                      | 120 ft    | 1 round                | S,M   |               |        |
| [[Mind Blank]]                         | 8   | abjuration    | Action                                      | Touch     | 24 hours               | V,S   |               |        |
| [[Minor Illusion]]                     | 0   | illusion      | Action                                      | 30 ft     | 1 minute               | S,M   |               |        |
| [[Mirage Arcane]]                      | 7   | illusion      | 10 minutes                                  | Sight     | 10 days                | V,S   |               |        |
| [[Mirror Image]]                       | 2   | illusion      | Action                                      | Self      | 1 minute               | V,S   |               |        |
| [[Mislead]]                            | 5   | illusion      | Action                                      | Self      | 1 hour                 | S     | Concentration |        |
| [[Modify Memory]]                      | 5   | enchantment   | Action                                      | 30 ft     | 1 minute               | V,S   | Concentration |        |
| [[Mordenkainen's Magnificent Mansion]] | 7   | conjuration   | 1 minute                                    | 300 ft    | 24 hours               | V,S,M |               |        |
| [[Mordenkainen's Sword]]               | 7   | evocation     | Action                                      | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Nondetection]]                       | 3   | abjuration    | Action                                      | Touch     | 8 hours                | V,S,M |               |        |
| [[Otto's Irresistible Dance]]          | 6   | enchantment   | Action                                      | 30 ft     | 1 minute               | V     | Concentration |        |
| [[Phantasmal Force]]                   | 2   | illusion      | Action                                      | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Phantasmal Killer]]                  | 4   | illusion      | Action                                      | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Planar Binding]]                     | 5   | abjuration    | 1 hour                                      | 60 ft     | 24 hours               | V,S,M |               |        |
| [[Plant Growth]]                       | 3   | transmutation | Action (Overgrowth) or 8 hours (Enrichment) | 150 ft    | Instantaneous          | V,S   |               |        |
| [[Polymorph]]                          | 4   | transmutation | Action                                      | 60 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Power Word Fortify]]                 | 7   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Power Word Heal]]                    | 9   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Power Word Kill]]                    | 9   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Power Word Stun]]                    | 8   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Prestidigitation]]                   | 0   | transmutation | Action                                      | 10 ft     | 1 hour                 | V,S   |               |        |
| [[Prismatic Spray]]                    | 7   | evocation     | Action                                      | Self      | Instantaneous          | V,S   |               |        |
| [[Prismatic Wall]]                     | 9   | abjuration    | Action                                      | 60 ft     | 10 minutes             | V,S   |               |        |
| [[Programmed Illusion]]                | 6   | illusion      | Action                                      | 120 ft    | Dispelled              | V,S,M |               |        |
| [[Project Image]]                      | 7   | illusion      | Action                                      | 500 miles | 1 day                  | V,S,M | Concentration |        |
| [[Raise Dead]]                         | 5   | necromancy    | 1 hour                                      | Touch     | Instantaneous          | V,S,M |               |        |
| [[Rary's Telepathic Bond]]             | 5   | divination    | Action or Ritual                            | 30 ft     | 1 hour                 | V,S,M |               | Ritual |
| [[Regenerate]]                         | 7   | transmutation | 1 minute                                    | Touch     | 1 hour                 | V,S,M |               |        |
| [[Resurrection]]                       | 7   | necromancy    | 1 hour                                      | Touch     | Instantaneous          | V,S,M |               |        |
| [[Scrying]]                            | 5   | divination    | 10 minutes                                  | Self      | 10 minutes             | V,S,M | Concentration |        |
| [[See Invisibility]]                   | 2   | divination    | Action                                      | Self      | 1 hour                 | V,S,M |               |        |
| [[Seeming]]                            | 5   | illusion      | Action                                      | 30 ft     | 8 hours                | V,S   |               |        |
| [[Sending]]                            | 3   | divination    | Action                                      | Unlimited | Instantaneous          | V,S,M |               |        |
| [[Shatter]]                            | 2   | evocation     | Action                                      | 60 ft     | Instantaneous          | V,S,M |               |        |
| [[Silence]]                            | 2   | illusion      | Action or Ritual                            | 120 ft    | 10 minutes             | V,S   | Concentration | Ritual |
| [[Silent Image]]                       | 1   | illusion      | Action                                      | 60 ft     | 10 minutes             | V,S,M | Concentration |        |
| [[Sleep]]                              | 1   | enchantment   | Action                                      | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Slow]]                               | 3   | transmutation | Action                                      | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Speak with Animals]]                 | 1   | divination    | Action or Ritual                            | Self      | 10 minutes             | V,S   |               | Ritual |
| [[Speak with Dead]]                    | 3   | necromancy    | Action                                      | 10 ft     | 10 minutes             | V,S,M |               |        |
| [[Speak with Plants]]                  | 3   | transmutation | Action                                      | Self      | 10 minutes             | V,S   |               |        |
| [[Starry Wisp]]                        | 0   | evocation     | Action                                      | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Stinking Cloud]]                     | 3   | conjuration   | Action                                      | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Suggestion]]                         | 2   | enchantment   | Action                                      | 30 ft     | 8 hours                | V,M   | Concentration |        |
| [[Symbol]]                             | 7   | abjuration    | 1 minute                                    | Touch     | Dispelled or triggered | V,S,M |               |        |
| [[Synaptic Static]]                    | 5   | enchantment   | Action                                      | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Tasha's Hideous Laughter]]           | 1   | enchantment   | Action                                      | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Teleport]]                           | 7   | conjuration   | Action                                      | 10 ft     | Instantaneous          | V     |               |        |
| [[Teleportation Circle]]               | 5   | conjuration   | 1 minute                                    | 10 ft     | 1 round                | V,M   |               |        |
| [[Thunderclap]]                        | 0   | evocation     | Action                                      | Self      | Instantaneous          | S     |               |        |
| [[Thunderwave]]                        | 1   | evocation     | Action                                      | Self      | Instantaneous          | V,S   |               |        |
| [[Tongues]]                            | 3   | divination    | Action                                      | Touch     | 1 hour                 | V,M   |               |        |
| [[True Polymorph]]                     | 9   | transmutation | Action                                      | 30 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[True Seeing]]                        | 6   | divination    | Action                                      | Touch     | 1 hour                 | V,S,M |               |        |
| [[True Strike]]                        | 0   | divination    | Action                                      | Self      | Instantaneous          | S,M   |               |        |
| [[Unseen Servant]]                     | 1   | conjuration   | Action or Ritual                            | 60 ft     | 1 hour                 | V,S,M |               | Ritual |
| [[Vicious Mockery]]                    | 0   | enchantment   | Action                                      | 60 ft     | Instantaneous          | V     |               |        |
| [[Yolande's Regal Presence]]           | 5   | enchantment   | Action                                      | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Zone of Truth]]                      | 2   | enchantment   | Action                                      | 60 ft     | 10 minutes             | V,S   |               |        |