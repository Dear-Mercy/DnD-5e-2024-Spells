
|                                        |     |               |                    |           |                        |       |               |        |
| -------------------------------------- | --- | ------------- | ------------------ | --------- | ---------------------- | ----- | ------------- | ------ |
| [[Acid Splash]]                        | 0   | evocation     | Action             | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Alarm]]                              | 1   | abjuration    | 1 minute or Ritual | 30 ft     | 8 hours                | V,S,M |               | Ritual |
| [[Alter Self]]                         | 2   | transmutation | Action             | Self      | 1 hour                 | V,S   | Concentration |        |
| [[Animate Dead]]                       | 3   | necromancy    | 1 minute           | 10 ft     | Instantaneous          | V,S,M |               |        |
| [[Animate Objects]]                    | 5   | transmutation | Action             | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Antimagic Field]]                    | 8   | abjuration    | Action             | Self      | 1 hour                 | V,S,M | Concentration |        |
| [[Antipathy Sympathy]]                 | 8   | enchantment   | 1 hour             | 60 ft     | 10 days                | V,S,M |               |        |
| [[Arcane Eye]]                         | 4   | divination    | Action             | 30 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Arcane Gate]]                        | 6   | conjuration   | Action             | 500 ft    | 10 minutes             | V,S   | Concentration |        |
| [[Arcane Lock]]                        | 2   | abjuration    | Action             | Touch     | Dispelled              | V,S,M |               |        |
| [[Arcane Vigor]]                       | 2   | abjuration    | Bonus Action       | Self      | Instantaneous          | V,S   |               |        |
| [[Astral Projection]]                  | 9   | necromancy    | 1 hour             | 10 ft     | Dispelled              | V,S,M |               |        |
| [[Augury]]                             | 2   | divination    | 1 minute or Ritual | Self      | Instantaneous          | V,S,M |               | Ritual |
| [[Banishment]]                         | 4   | abjuration    | Action             | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Befuddlement]]                       | 8   | enchantment   | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Bestow Curse]]                       | 3   | necromancy    | Action             | Touch     | 1 minute               | V,S   | Concentration |        |
| [[Bigby's Hand]]                       | 5   | evocation     | Action             | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Blade Ward]]                         | 0   | abjuration    | Action             | Self      | 1 minute               | V,S   | Concentration |        |
| [[Blight]]                             | 4   | necromancy    | Action             | 30 ft     | Instantaneous          | V,S   |               |        |
| [[Blindness Deafness]]                 | 2   | transmutation | Action             | 120 ft    | 1 minute               | V     |               |        |
| [[Blink]]                              | 3   | transmutation | Action             | Self      | 1 minute               | V,S   |               |        |
| [[Blur]]                               | 2   | illusion      | Action             | Self      | 1 minute               | V     | Concentration |        |
| [[Burning Hands]]                      | 1   | evocation     | Action             | Self      | Instantaneous          | V,S   |               |        |
| [[Chain Lightning]]                    | 6   | evocation     | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Charm Monster]]                      | 4   | enchantment   | Action             | 30 ft     | 1 hour                 | V,S   |               |        |
| [[Charm Person]]                       | 1   | enchantment   | Action             | 30 ft     | 1 hour                 | V,S   |               |        |
| [[Chill Touch]]                        | 0   | necromancy    | Action             | Touch     | Instantaneous          | V,S   |               |        |
| [[Chromatic Orb]]                      | 1   | evocation     | Action             | 90 ft     | Instantaneous          | V,S,M |               |        |
| [[Circle of Death]]                    | 6   | necromancy    | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Circle of Power]]                    | 5   | abjuration    | Action             | Self      | 10 minutes             | V     | Concentration |        |
| [[Clairvoyance]]                       | 3   | divination    | 10 minutes         | 1 mile    | 10 minutes             | V,S,M | Concentration |        |
| [[Clone]]                              | 8   | necromancy    | 1 hour             | Touch     | Instantaneous          | V,S,M |               |        |
| [[Cloud of Daggers]]                   | 2   | conjuration   | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Cloudkill]]                          | 5   | conjuration   | Action             | 120 ft    | 10 minutes             | V,S   | Concentration |        |
| [[Color Spray]]                        | 1   | illusion      | Action             | Self      | Instantaneous          | V,S,M |               |        |
| [[Comprehend Languages]]               | 1   | divination    | Action or Ritual   | Self      | 1 hour                 | V,S,M |               | Ritual |
| [[Cone of Cold]]                       | 5   | evocation     | Action             | Self      | Instantaneous          | V,S,M |               |        |
| [[Confusion]]                          | 4   | enchantment   | Action             | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Conjure Elemental]]                  | 5   | conjuration   | Action             | 60 ft     | 10 minutes             | V,S   | Concentration |        |
| [[Conjure Minor Elementals]]           | 4   | conjuration   | Action             | Self      | 10 minutes             | V,S   | Concentration |        |
| [[Contact Other Plane]]                | 5   | divination    | 1 minute or Ritual | Self      | 1 minute               | V     |               | Ritual |
| [[Contingency]]                        | 6   | abjuration    | 10 minutes         | Self      | 10 days                | V,S,M |               |        |
| [[Continual Flame]]                    | 2   | evocation     | Action             | Touch     | Dispelled              | V,S,M |               |        |
| [[Control Water]]                      | 4   | transmutation | Action             | 300 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Control Weather]]                    | 8   | transmutation | 10 minutes         | Self      | 8 hours                | V,S,M | Concentration |        |
| [[Counterspell]]                       | 3   | abjuration    | Reaction           | 60 ft     | Instantaneous          | S     |               |        |
| [[Create Undead]]                      | 6   | necromancy    | 1 minute           | 10 ft     | Instantaneous          | V,S,M |               |        |
| [[Creation]]                           | 5   | illusion      | 1 minute           | 30 ft     | Special                | V,S,M |               |        |
| [[Crown of Madness]]                   | 2   | enchantment   | Action             | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Dancing Lights]]                     | 0   | illusion      | Action             | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Darkness]]                           | 2   | evocation     | Action             | 60 ft     | 10 minutes             | V,M   | Concentration |        |
| [[Darkvision]]                         | 2   | transmutation | Action             | Touch     | 8 hours                | V,S,M |               |        |
| [[Delayed Blast Fireball]]             | 7   | evocation     | Action             | 150 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Demiplane]]                          | 8   | conjuration   | Action             | 60 ft     | 1 hour                 | S     |               |        |
| [[Detect Magic]]                       | 1   | divination    | Action or Ritual   | Self      | 10 minutes             | V,S   | Concentration | Ritual |
| [[Detect Thoughts]]                    | 2   | divination    | Action             | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Dimension Door]]                     | 4   | conjuration   | Action             | 500 ft    | Instantaneous          | V     |               |        |
| [[Disguise Self]]                      | 1   | illusion      | Action             | Self      | 1 hour                 | V,S   |               |        |
| [[Disintegrate]]                       | 6   | transmutation | Action             | 60 ft     | Instantaneous          | V,S,M |               |        |
| [[Dispel Magic]]                       | 3   | abjuration    | Action             | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Divination]]                         | 4   | divination    | Action or Ritual   | Self      | Instantaneous          | V,S,M |               | Ritual |
| [[Dominate Monster]]                   | 8   | enchantment   | Action             | 60 ft     | 1 hour                 | V,S   | Concentration |        |
| [[Dominate Person]]                    | 5   | enchantment   | Action             | 60 ft     | 1 minute               | V,S   | Concentration |        |
| [[Dragon's Breath]]                    | 2   | transmutation | Bonus Action       | Touch     | 1 minute               | V,S,M | Concentration |        |
| [[Drawmij's Instant Summons]]          | 6   | conjuration   | 1 minute or Ritual | Touch     | Dispelled              | V,S,M |               | Ritual |
| [[Dream]]                              | 5   | illusion      | 1 minute           | Special   | 8 hours                | V,S,M |               |        |
| [[Elementalism]]                       | 0   | transmutation | Action             | 30 ft     | Instantaneous          | V,S   |               |        |
| [[Enhance Ability]]                    | 2   | transmutation | Action             | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Enlarge Reduce]]                     | 2   | transmutation | Action             | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Etherealness]]                       | 7   | conjuration   | Action             | Self      | 8 hours                | V,S   |               |        |
| [[Evard's Black Tentacles]]            | 4   | conjuration   | Action             | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Expeditious Retreat]]                | 1   | transmutation | Bonus Action       | Self      | 10 minutes             | V,S   | Concentration |        |
| [[Eyebite]]                            | 6   | necromancy    | Action             | Self      | 1 minute               | V,S   | Concentration |        |
| [[Fabricate]]                          | 4   | transmutation | 10 minutes         | 120 ft    | Instantaneous          | V,S   |               |        |
| [[False Life]]                         | 1   | necromancy    | Action             | Self      | Instantaneous          | V,S,M |               |        |
| [[Fear]]                               | 3   | illusion      | Action             | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Feather Fall]]                       | 1   | transmutation | Reaction           | 60 ft     | 1 minute               | V,M   |               |        |
| [[Feign Death]]                        | 3   | necromancy    | Action or Ritual   | Touch     | 1 hour                 | V,S,M |               | Ritual |
| [[Find Familiar]]                      | 1   | conjuration   | 1 hour or Ritual   | 10 ft     | Instantaneous          | V,S,M |               | Ritual |
| [[Finger of Death]]                    | 7   | necromancy    | Action             | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Fire Bolt]]                          | 0   | evocation     | Action             | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Fire Shield]]                        | 4   | evocation     | Action             | Self      | 10 minutes             | V,S,M |               |        |
| [[Fireball]]                           | 3   | evocation     | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Flaming Sphere]]                     | 2   | conjuration   | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Flesh to Stone]]                     | 6   | transmutation | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Fly]]                                | 3   | transmutation | Action             | Touch     | 10 minutes             | V,S,M | Concentration |        |
| [[Fog Cloud]]                          | 1   | conjuration   | Action             | 120 ft    | 1 hour                 | V,S   | Concentration |        |
| [[Forcecage]]                          | 7   | evocation     | Action             | 100 ft    | 1 hour                 | V,S,M |               |        |
| [[Foresight]]                          | 9   | divination    | 1 minute           | Touch     | 8 hours                | V,S,M |               |        |
| [[Friends]]                            | 0   | enchantment   | Action             | 10 ft     | 1 minute               | S,M   | Concentration |        |
| [[Gaseous Form]]                       | 3   | transmutation | Action             | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Gate]]                               | 9   | conjuration   | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Geas]]                               | 5   | enchantment   | 1 minute           | 60 ft     | 30 days                | V     |               |        |
| [[Gentle Repose]]                      | 2   | necromancy    | Action or Ritual   | Touch     | 10 days                | V,S,M |               | Ritual |
| [[Globe of Invulnerability]]           | 6   | abjuration    | Action             | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Glyph of Warding]]                   | 3   | abjuration    | 1 hour             | Touch     | Dispelled or triggered | V,S,M |               |        |
| [[Grease]]                             | 1   | conjuration   | Action             | 60 ft     | 1 minute               | V,S,M |               |        |
| [[Greater Invisibility]]               | 4   | illusion      | Action             | Touch     | 1 minute               | V,S   | Concentration |        |
| [[Guards and Wards]]                   | 6   | abjuration    | 1 hour             | Touch     | 24 hours               | V,S,M |               |        |
| [[Gust of Wind]]                       | 2   | evocation     | Action             | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Hallucinatory Terrain]]              | 4   | illusion      | 10 minutes         | 300 ft    | 24 hours               | V,S,M |               |        |
| [[Haste]]                              | 3   | transmutation | Action             | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Hold Monster]]                       | 5   | enchantment   | Action             | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Hold Person]]                        | 2   | enchantment   | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Hypnotic Pattern]]                   | 3   | illusion      | Action             | 120 ft    | 1 minute               | S,M   | Concentration |        |
| [[Ice Knife]]                          | 1   | conjuration   | Action             | 60 ft     | Instantaneous          | S,M   |               |        |
| [[Ice Storm]]                          | 4   | evocation     | Action             | 300 ft    | Instantaneous          | V,S,M |               |        |
| [[Identify]]                           | 1   | divination    | 1 minute or Ritual | Touch     | Instantaneous          | V,S,M |               | Ritual |
| [[Illusory Script]]                    | 1   | illusion      | 1 minute or Ritual | Touch     | 10 days                | S,M   |               | Ritual |
| [[Imprisonment]]                       | 9   | abjuration    | 1 minute           | 30 ft     | Dispelled              | V,S,M |               |        |
| [[Incendiary CLoud]]                   | 8   | conjuration   | Action             | 150 ft    | 1 minute               | V,S   | Concentration |        |
| [[Invisibility]]                       | 2   | illusion      | Action             | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Jallarzi's Storm of Radiance]]       | 5   | evocation     | Action             | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Jump]]                               | 1   | transmutation | Bonus Action       | Touch     | 1 minute               | V,S,M |               |        |
| [[Knock]]                              | 2   | transmutation | Action             | 60 ft     | Instantaneous          | V     |               |        |
| [[Legend Lore]]                        | 5   | divination    | 10 minutes         | Self      | Instantaneous          | V,S,M |               |        |
| [[Leomund's Secret Chest]]             | 4   | conjuration   | Action             | Touch     | Instantaneous          | V,S,M |               |        |
| [[Leomund's Tiny Hut]]                 | 3   | evocation     | 1 minute or Ritual | Self      | 8 hours                | V,S,M |               | Ritual |
| [[Levitate]]                           | 2   | transmutation | Action             | 60 ft     | 10 minutes             | V,S,M | Concentration |        |
| [[Light]]                              | 0   | evocation     | Action             | Touch     | 1 hour                 | V,M   |               |        |
| [[Lightning Bolt]]                     | 3   | evocation     | Action             | Self      | Instantaneous          | V,S,M |               |        |
| [[Locate Creature]]                    | 4   | divination    | Action             | Self      | 1 hour                 | V,S,M | Concentration |        |
| [[Locate Object]]                      | 2   | divination    | Action             | Self      | 10 minutes             | V,S,M | Concentration |        |
| [[Longstrider]]                        | 1   | transmutation | Action             | Touch     | 1 hour                 | V,S,M |               |        |
| [[Mage Armor]]                         | 1   | abjuration    | Action             | Touch     | 8 hours                | V,S,M |               |        |
| [[Mage Hand]]                          | 0   | conjuration   | Action             | 30 ft     | 1 minute               | V,S   |               |        |
| [[Magic Circle]]                       | 3   | abjuration    | 1 minute           | 10 ft     | 1 hour                 | V,S,M |               |        |
| [[Magic Jar]]                          | 6   | necromancy    | 1 minute           | Self      | Dispelled              | V,S,M |               |        |
| [[Magic Missile]]                      | 1   | evocation     | Action             | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Magic Mouth]]                        | 2   | illusion      | 1 minute or Ritual | 30 ft     | Dispelled              | V,S,M |               | Ritual |
| [[Magic Weapon]]                       | 2   | transmutation | Bonus Action       | Touch     | 1 hour                 | V,S   |               |        |
| [[Major Image]]                        | 3   | illusion      | Action             | 120 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Mass Suggestion]]                    | 6   | enchantment   | Action             | 60 ft     | 24 hours               | V,M   |               |        |
| [[Maze]]                               | 8   | conjuration   | Action             | 60 ft     | 10 minutes             | V,S   | Concentration |        |
| [[Melf's Acid Arrow]]                  | 2   | evocation     | Action             | 90 ft     | Instantaneous          | V,S,M |               |        |
| [[Mending]]                            | 0   | transmutation | 1 minute           | Touch     | Instantaneous          | V,S,M |               |        |
| [[Message]]                            | 0   | transmutation | Action             | 120 ft    | 1 round                | S,M   |               |        |
| [[Meteor Swarm]]                       | 9   | evocation     | Action             | 1 mile    | Instantaneous          | V,S   |               |        |
| [[Mind Blank]]                         | 8   | abjuration    | Action             | Touch     | 24 hours               | V,S   |               |        |
| [[Mind Sliver]]                        | 0   | enchantment   | Action             | 60 ft     | 1 round                | V     |               |        |
| [[Mind Spike]]                         | 2   | divination    | Action             | 120 ft    | 1 hour                 | S     | Concentration |        |
| [[Minor Illusion]]                     | 0   | illusion      | Action             | 30 ft     | 1 minute               | S,M   |               |        |
| [[Mirage Arcane]]                      | 7   | illusion      | 10 minutes         | Sight     | 10 days                | V,S   |               |        |
| [[Mirror Image]]                       | 2   | illusion      | Action             | Self      | 1 minute               | V,S   |               |        |
| [[Mislead]]                            | 5   | illusion      | Action             | Self      | 1 hour                 | S     | Concentration |        |
| [[Misty Step]]                         | 2   | conjuration   | Bonus Action       | Self      | Instantaneous          | V     |               |        |
| [[Modify Memory]]                      | 5   | enchantment   | Action             | 30 ft     | 1 minute               | V,S   | Concentration |        |
| [[Mordenkainen's Faithful Hound]]      | 4   | conjuration   | Action             | 30 ft     | 8 hours                | V,S,M |               |        |
| [[Mordenkainen's Magnificent Mansion]] | 7   | conjuration   | 1 minute           | 300 ft    | 24 hours               | V,S,M |               |        |
| [[Mordenkainen's Private Sanctum]]     | 4   | abjuration    | 10 minutes         | 120 ft    | 24 hours               | V,S,M |               |        |
| [[Mordenkainen's Sword]]               | 7   | evocation     | Action             | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Move Earth]]                         | 6   | transmutation | Action             | 120 ft    | 2 hours                | V,S,M | Concentration |        |
| [[Nondetection]]                       | 3   | abjuration    | Action             | Touch     | 8 hours                | V,S,M |               |        |
| [[Nystul's Magic Aura]]                | 2   | illusion      | Action             | Touch     | 24 hours               | V,S,M |               |        |
| [[Otiluke's Freezing Sphere]]          | 6   | evocation     | Action             | 300 ft    | Instantaneous          | V,S,M |               |        |
| [[Otiluke's Resilient Sphere]]         | 4   | evocation     | Action             | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Otto's Irresistible Dance]]          | 6   | enchantment   | Action             | 30 ft     | 1 minute               | V     | Concentration |        |
| [[Passwall]]                           | 5   | transmutation | Action             | 30 ft     | 1 hour                 | V,S,M |               |        |
| [[Phantasmal Force]]                   | 2   | illusion      | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Phantasmal Killer]]                  | 4   | illusion      | Action             | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Phantom Steed]]                      | 3   | illusion      | 1 minute or Ritual | 30 ft     | 1 hour                 | V,S   |               | Ritual |
| [[Planar Binding]]                     | 5   | abjuration    | 1 hour             | 60 ft     | 24 hours               | V,S,M |               |        |
| [[Plane Shift]]                        | 7   | conjuration   | Action             | Touch     | Instantaneous          | V,S,M |               |        |
| [[Poison Spray]]                       | 0   | necromancy    | Action             | 30 ft     | Instantaneous          | V,S   |               |        |
| [[Polymorph]]                          | 4   | transmutation | Action             | 60 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Power Word Kill]]                    | 9   | enchantment   | Action             | 60 ft     | Instantaneous          | V     |               |        |
| [[Power Word Stun]]                    | 8   | enchantment   | Action             | 60 ft     | Instantaneous          | V     |               |        |
| [[Prestidigitation]]                   | 0   | transmutation | Action             | 10 ft     | 1 hour                 | V,S   |               |        |
| [[Prismatic Spray]]                    | 7   | evocation     | Action             | Self      | Instantaneous          | V,S   |               |        |
| [[Prismatic Wall]]                     | 9   | abjuration    | Action             | 60 ft     | 10 minutes             | V,S   |               |        |
| [[Programmed Illusion]]                | 6   | illusion      | Action             | 120 ft    | Dispelled              | V,S,M |               |        |
| [[Project Image]]                      | 7   | illusion      | Action             | 500 miles | 1 day                  | V,S,M | Concentration |        |
| [[Protection from Energy]]             | 3   | abjuration    | Action             | Touch     | 1 hour                 | V,S   | Concentration |        |
| [[Protection from Evil and Good]]      | 1   | abjuration    | Action             | Touch     | 10 minutes             | V,S,M | Concentration |        |
| [[Rary's Telepathic Bond]]             | 5   | divination    | Action or Ritual   | 30 ft     | 1 hour                 | V,S,M |               | Ritual |
| [[Ray of Enfeeblement]]                | 2   | necromancy    | Action             | 60 ft     | 1 minute               | V,S   | Concentration |        |
| [[Ray of Frost]]                       | 0   | evocation     | Action             | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Ray of Sickness]]                    | 1   | necromancy    | Action             | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Remove Curse]]                       | 3   | abjuration    | Action             | Touch     | Instantaneous          | V,S   |               |        |
| [[Reverse Gravity]]                    | 7   | transmutation | Action             | 100 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Rope Trick]]                         | 2   | transmutation | Action             | Touch     | 1 hour                 | V,S,M |               |        |
| [[Scorching Ray]]                      | 2   | evocation     | Action             | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Scrying]]                            | 5   | divination    | 10 minutes         | Self      | 10 minutes             | V,S,M | Concentration |        |
| [[See Invisibility]]                   | 2   | divination    | Action             | Self      | 1 hour                 | V,S,M |               |        |
| [[Seeming]]                            | 5   | illusion      | Action             | 30 ft     | 8 hours                | V,S   |               |        |
| [[Sending]]                            | 3   | divination    | Action             | Unlimited | Instantaneous          | V,S,M |               |        |
| [[Sequester]]                          | 7   | transmutation | Action             | Touch     | Dispelled              | V,S,M |               |        |
| [[Shapechange]]                        | 9   | transmutation | Action             | Self      | 1 hour                 | V,S,M | Concentration |        |
| [[Shatter]]                            | 2   | evocation     | Action             | 60 ft     | Instantaneous          | V,S,M |               |        |
| [[Shield]]                             | 1   | abjuration    | Reaction           | Self      | 1 round                | V,S   |               |        |
| [[Shocking Grasp]]                     | 0   | evocation     | Action             | Touch     | Instantaneous          | V,S   |               |        |
| [[Silent Image]]                       | 1   | illusion      | Action             | 60 ft     | 10 minutes             | V,S,M | Concentration |        |
| [[Simulacrum]]                         | 7   | illusion      | 12 hours           | Touch     | Dispelled              | V,S,M |               |        |
| [[Sleep]]                              | 1   | enchantment   | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Sleet Storm]]                        | 3   | conjuration   | Action             | 150 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Slow]]                               | 3   | transmutation | Action             | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Speak with Dead]]                    | 3   | necromancy    | Action             | 10 ft     | 10 minutes             | V,S,M |               |        |
| [[Spider Climb]]                       | 2   | transmutation | Action             | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Steel Wind Strike]]                  | 5   | conjuration   | Action             | 30 ft     | Instantaneous          | S,M   |               |        |
| [[Stinking Cloud]]                     | 3   | conjuration   | Action             | 90 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Stone Shape]]                        | 4   | transmutation | Action             | Touch     | Instantaneous          | V,S,M |               |        |
| [[Stoneskin]]                          | 4   | transmutation | Action             | Touch     | 1 hour                 | V,S,M | Concentration |        |
| [[Suggestion]]                         | 2   | enchantment   | Action             | 30 ft     | 8 hours                | V,M   | Concentration |        |
| [[Summon Aberration]]                  | 4   | conjuration   | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Construct]]                   | 4   | conjuration   | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Dragon]]                      | 5   | conjuration   | Action             | 60 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Elemental]]                   | 4   | conjuration   | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Fey]]                         | 3   | conjuration   | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Fiend]]                       | 6   | conjuration   | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Summon Undead]]                      | 3   | necromancy    | Action             | 90 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Sunbeam]]                            | 6   | evocation     | Action             | Self      | 1 minute               | V,S,M | Concentration |        |
| [[Sunburst]]                           | 8   | evocation     | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Symbol]]                             | 7   | abjuration    | 1 minute           | Touch     | Dispelled or triggered | V,S,M |               |        |
| [[Synaptic Static]]                    | 5   | enchantment   | Action             | 120 ft    | Instantaneous          | V,S   |               |        |
| [[Tasha's Bubbling Cauldron]]          | 6   | conjuration   | Action             | 5 ft      | 10 minutes             | V,S,M |               |        |
| [[Tasha's Hideous Laughter]]           | 1   | enchantment   | Action             | 30 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Telekinesis]]                        | 5   | transmutation | Action             | 60 ft     | 10 minutes             | V,S   | Concentration |        |
| [[Telepathy]]                          | 8   | divination    | Action             | Unlimited | 24 hours               | V,S,M |               |        |
| [[Teleport]]                           | 7   | conjuration   | Action             | 10 ft     | Instantaneous          | V     |               |        |
| [[Teleportation Circle]]               | 5   | conjuration   | 1 minute           | 10 ft     | 1 round                | V,M   |               |        |
| [[Tenser's Floating Disk]]             | 1   | conjuration   | Action or Ritual   | 30 ft     | 1 hour                 | V,S,M |               | Ritual |
| [[Thunderclap]]                        | 0   | evocation     | Action             | Self      | Instantaneous          | S     |               |        |
| [[Thunderwave]]                        | 1   | evocation     | Action             | Self      | Instantaneous          | V,S   |               |        |
| [[Time Stop]]                          | 9   | transmutation | Action             | Self      | Instantaneous          | V     |               |        |
| [[Toll the Dead]]                      | 0   | necromancy    | Action             | 60 ft     | Instantaneous          | V,S   |               |        |
| [[Tongues]]                            | 3   | divination    | Action             | Touch     | 1 hour                 | V,M   |               |        |
| [[True Polymorph]]                     | 9   | transmutation | Action             | 30 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[True Seeing]]                        | 6   | divination    | Action             | Touch     | 1 hour                 | V,S,M |               |        |
| [[True Strike]]                        | 0   | divination    | Action             | Self      | Instantaneous          | S,M   |               |        |
| [[Unseen Servant]]                     | 1   | conjuration   | Action or Ritual   | 60 ft     | 1 hour                 | V,S,M |               | Ritual |
| [[Vampiric Touch]]                     | 3   | necromancy    | Action             | Self      | 1 minute               | V,S   | Concentration |        |
| [[Vitriolic Sphere]]                   | 4   | evocation     | Action             | 150 ft    | Instantaneous          | V,S,M |               |        |
| [[Wall of Fire]]                       | 4   | evocation     | Action             | 120 ft    | 1 minute               | V,S,M | Concentration |        |
| [[Wall of Force]]                      | 5   | evocation     | Action             | 120 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Wall of Ice]]                        | 6   | evocation     | Action             | 120 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Wall of Stone]]                      | 5   | evocation     | Action             | 120 ft    | 10 minutes             | V,S,M | Concentration |        |
| [[Water Breathing]]                    | 3   | transmutation | Action or Ritual   | 30 ft     | 24 hours               | V,S,M |               | Ritual |
| [[Web]]                                | 2   | conjuration   | Action             | 60 ft     | 1 hour                 | V,S,M | Concentration |        |
| [[Weird]]                              | 9   | illusion      | Action             | 120 ft    | 1 minute               | V,S   | Concentration |        |
| [[Wish]]                               | 9   | conjuration   | Action             | Self      | Instantaneous          | V     |               |        |
| [[Witch Bolt]]                         | 1   | evocation     | Action             | 60 ft     | 1 minute               | V,S,M | Concentration |        |
| [[Yolande's Regal Presence]]           | 5   | enchantment   | Action             | Self      | 1 minute               | V,S,M | Concentration |        |