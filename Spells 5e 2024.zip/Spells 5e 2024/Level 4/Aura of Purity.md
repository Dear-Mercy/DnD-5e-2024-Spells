level 4 - #abjuration Casting Time: Action Range: Self Components: V Duration: #Concentration, up to 10 minutes 

An aura radiates from you in a 30-foot Emanation for the duration. While in the aura, you and your allies have Resistance to Poison damage and Advantage on saving throws to avoid or end effects that include the Blinded, Charmed, Deafened, Frightened, Paralyzed, Poisoned, or Stunned condition.


#Cleric #Paladin
