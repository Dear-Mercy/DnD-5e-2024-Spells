level 4 - #transmutation Casting Time: Action Range: Touch Components: V, S, M (diamond dust worth 100+ GP, which the spell consumes) Duration: #Concentration, up to 1 hour 

Until the spell ends, one willing creature you touch has Resistance to Bludgeoning, Piercing, and Slashing damage


#Druid #Ranger #Sorcerer #Wizard
