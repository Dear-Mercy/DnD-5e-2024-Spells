level 4 - #illusion Casting Time: Action Range: Touch Components: V, S Duration: #Concentration, up to 1 minute 

A creature you touch has the Invisible condition until the spell ends.


#Bard #Sorcerer #Wizard
