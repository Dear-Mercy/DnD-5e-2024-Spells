level 4 - #enchantment Casting Time: #BonusAction, which you take immediately after hitting a creature with a Melee weapon or an Unarmed Strike Range: Self Components: V Duration: Instantaneous 

The target takes an extra 4d6 Psychic damage from the attack, and the target must succeed on a Wisdom saving throw or have the Stunned condition until the end of your next turn. 

Using a Higher-Level Spell Slot. The extra damage increases by 1d6 for each spell slot level above 4


#Paladin
