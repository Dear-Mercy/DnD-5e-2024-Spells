|   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
|[[Aid]]|2|abjuration|Action|30 ft|8 hours|V,S,M|||
|[[Animal Friendship]]|1|enchantment|Action|30 ft|24 hours|V,S,M|||
|[[Animal Messenger]]|2|enchantment|Action or Ritual|30 ft|24 hours|V,S,M||Ritual|
|[[Animal Shapes]]|8|transmutation|Action|30 ft|24 hours|V,S|||
|[[Antilife Shell]]|5|abjuration|Action|Self|1 hour|V,S|Concentration|   |
|[[Antipathy/Sympathy]]|8|enchantment|1 hour|60 ft|10 days|V,S,M|||
|[[Augury]]|2|divination|1 minute or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Aura of Vitality]]|3|abjuration|Action|Self|1 minute|V|Concentration|   |
|[[Awaken]]|5|transmutation|8 hours|Touch|Instantaneous|V,S,M|||
|[[Barkskin]]|2|transmutation|Bonus Action|Touch|1 hour|V,S,M|||
|[[Beast Sense]]|2|divination|Action or Ritual|Touch|1 hour|S|Concentration|Ritual|
|[[Befuddlement]]|8|enchantment|Action|150 ft|Instantaneous|V,S,M|||
|[[Blight]]|4|necromancy|Action|30 ft|Instantaneous|V,S|||
|[[Call Lightning]]|3|conjuration|Action|120 ft|10 minutes|V,S|Concentration|   |
|[[Charm Monster]]|4|enchantment|Action|30 ft|1 hour|V,S|||
|[[Charm Person]]|1|enchantment|Action|30 ft|1 hour|V,S|||
|[[Commune with Nature]]|5|divination|1 minute or Ritual|Self|Instantaneous|V,S||Ritual|
|[[Cone of Cold]]|5|evocation|Action|Self|Instantaneous|V,S,M|||
|[[Confusion]]|4|enchantment|Action|90 ft|1 minute|V,S,M|Concentration|   |
|[[Conjure Animals]]|3|conjuration|Action|60 ft|10 minutes|V,S|Concentration|   |
|[[Conjure Elemental]]|5|conjuration|Action|60 ft|10 minutes|V,S|Concentration|   |
|[[Conjure Fey]]|6|conjuration|Action|60 ft|10 minutes|V,S|Concentration|   |
|[[Conjure Minor Elementals]]|4|conjuration|Action|Self|10 minutes|V,S|Concentration|   |
|[[Conjure Woodland Beings]]|4|conjuration|Action|Self|10 minutes|V,S|Concentration|   |
|[[Contagion]]|5|necromancy|Action|Touch|7 days|V,S|||
|[[Continual Flame]]|2|evocation|Action|Touch|Dispelled|V,S,M|||
|[[Control Water]]|4|transmutation|Action|300 ft|10 minutes|V,S,M|Concentration|   |
|[[Control Weather]]|8|transmutation|10 minutes|Self|8 hours|V,S,M|Concentration|   |
|[[Create or Destroy Water]]|1|transmutation|Action|30 ft|Instantaneous|V,S,M|||
|[[Cure Wounds]]|1|abjuration|Action|Touch|Instantaneous|V,S|||
|[[Darkvision]]|2|transmutation|Action|Touch|8 hours|V,S,M|||
|[[Daylight]]|3|evocation|Action|60 ft|1 hour|V,S|||
|[[Detect Magic]]|1|divination|Action or Ritual|Self|10 minutes|V,S|Concentration|Ritual|
|[[Detect Poison and Disease]]|1|divination|Action or Ritual|Self|10 minutes|V,S,M|Concentration|Ritual|
|[[Dispel Magic]]|3|abjuration|Action|120 ft|Instantaneous|V,S|||
|[[Divination]]|4|divination|Action or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Dominate Beast]]|4|enchantment|Action|60 ft|1 minute|V,S|Concentration|   |
|[[Druidcraft]]|0|transmutation|Action|30 ft|Instantaneous|V,S|||
|[[Earthquake]]|8|transmutation|Action|500 ft|1 minute|V,S,M|Concentration|   |
|[[Elemental Weapon]]|3|transmutation|Action|Touch|1 hour|V,S|Concentration|   |
|[[Elementalism]]|0|transmutation|Action|30 ft|Instantaneous|V,S|||
|[[Enhance Ability]]|2|transmutation|Action|Touch|1 hour|V,S,M|Concentration|   |
|[[Enlarge/Reduce]]|2|transmutation|Action|30 ft|1 minute|V,S,M|Concentration|   |
|[[Entangle]]|1|conjuration|Action|90 ft|1 minute|V,S|Concentration|   |
|[[Faerie Fire]]|1|evocation|Action|60 ft|1 minute|V|Concentration|   |
|[[Feign Death]]|3|necromancy|Action or Ritual|Touch|1 hour|V,S,M||Ritual|
|[[Find the Path]]|6|divination|1 minute|Self|1 day|V,S,M|Concentration|   |
|[[Find Traps]]|2|divination|Action|120 ft|Instantaneous|V,S|||
|[[Fire Shield]]|4|evocation|Action|Self|10 minutes|V,S,M|||
|[[Fire Storm]]|7|evocation|Action|150 ft|Instantaneous|V,S|||
|[[Flame Blade]]|2|evocation|Bonus Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Flaming Sphere]]|2|conjuration|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Flesh to Stone]]|6|transmutation|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Fog Cloud]]|1|conjuration|Action|120 ft|1 hour|V,S|Concentration|   |
|[[Foresight]]|9|divination|1 minute|Touch|8 hours|V,S,M|||
|[[Fount of Moonlight]]|4|evocation|Action|Self|10 minutes|V,S|Concentration|   |
|[[Freedom of Movement]]|4|abjuration|Action|Touch|1 hour|V,S,M|||
|[[Geas]]|5|enchantment|1 minute|60 ft|30 days|V|||
|[[Giant Insect]]|4|conjuration|Action|60 ft|10 minutes|V,S|Concentration|   |
|[[Goodberry]]|1|conjuration|Action|Self|24 hours|V,S,M|||
|[[Grasping Vine]]|4|conjuration|Bonus Action|60 ft|1 minute|V,S|Concentration|   |
|[[Greater Restoration]]|5|abjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Guidance]]|0|divination|Action|Touch|1 minute|V,S|Concentration|   |
|[[Gust of Wind]]|2|evocation|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Hallucinatory Terrain]]|4|illusion|10 minutes|300 ft|24 hours|V,S,M|||
|[[Heal]]|6|abjuration|Action|60 ft|Instantaneous|V,S|||
|[[Healing Word]]|1|abjuration|Bonus Action|60 ft|Instantaneous|V|||
|[[Heat Metal]]|2|transmutation|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Heroes' Feast]]|6|conjuration|10 minutes|Self|Instantaneous|V,S,M|||
|[[Hold Person]]|2|enchantment|Action|60 ft|1 minute|V,S,M|Concentration|   |
|[[Ice Knife]]|1|conjuration|Action|60 ft|Instantaneous|S,M|||
|[[Ice Storm]]|4|evocation|Action|300 ft|Instantaneous|V,S,M|||
|[[Incendiary CLoud]]|8|conjuration|Action|150 ft|1 minute|V,S|Concentration|   |
|[[Insect Plague]]|5|conjuration|Action|300 ft|10 minutes|V,S,M|Concentration|   |
|[[Jump]]|1|transmutation|Bonus Action|Touch|1 minute|V,S,M|||
|[[Lesser Restoration]]|2|abjuration|Bonus Action|Touch|Instantaneous|V,S|||
|[[Locate Animals or Plants]]|2|divination|Action or Ritual|Self|Instantaneous|V,S,M||Ritual|
|[[Locate Creature]]|4|divination|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Locate Object]]|2|divination|Action|Self|10 minutes|V,S,M|Concentration|   |
|[[Longstrider]]|1|transmutation|Action|Touch|1 hour|V,S,M|||
|[[Mass Cure Wounds]]|5|abjuration|Action|60 ft|Instantaneous|V,S|||
|[[Meld into Stone]]|3|transmutation|Action or Ritual|Touch|8 hours|V,S||Ritual|
|[[Mending]]|0|transmutation|1 minute|Touch|Instantaneous|V,S,M|||
|[[Message]]|0|transmutation|Action|120 ft|1 round|S,M|||
|[[Mirage Arcane]]|7|illusion|10 minutes|Sight|10 days|V,S|||
|[[Moonbeam]]|2|evocation|Action|120 ft|1 minute|V,S,M|Concentration|   |
|[[Move Earth]]|6|transmutation|Action|120 ft|2 hours|V,S,M|Concentration|   |
|[[Pass without Trace]]|2|abjuration|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Planar Binding]]|5|abjuration|1 hour|60 ft|24 hours|V,S,M|||
|[[Plane Shift]]|7|conjuration|Action|Touch|Instantaneous|V,S,M|||
|[[Plant Growth]]|3|transmutation|Action (Overgrowth) or 8 hours (Enrichment)|150 ft|Instantaneous|V,S|||
|[[Poison Spray]]|0|necromancy|Action|30 ft|Instantaneous|V,S|||
|[[Polymorph]]|4|transmutation|Action|60 ft|1 hour|V,S,M|Concentration|   |
|[[Produce Flame]]|0|conjuration|Bonus Action|Self|10 minutes|V,S|||
|[[Protection from Energy]]|3|abjuration|Action|Touch|1 hour|V,S|Concentration|   |
|[[Protection from Evil and Good]]|1|abjuration|Action|Touch|10 minutes|V,S,M|Concentration|   |
|[[Protection from Poison]]|2|abjuration|Action|Touch|1 hour|V,S|||
|[[Purify Food and Drink]]|1|transmutation|Action or Ritual|10 ft|Instantaneous|V,S||Ritual|
|[[Regenerate]]|7|transmutation|1 minute|Touch|1 hour|V,S,M|||
|[[Reincarnate]]|5|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[Resistance]]|0|abjuration|Action|Touch|1 minute|V,S|Concentration|   |
|[[Reverse Gravity]]|7|transmutation|Action|100 ft|1 minute|V,S,M|Concentration|   |
|[[Revivify]]|3|necromancy|Action|Touch|Instantaneous|V,S,M|||
|[[Scrying]]|5|divination|10 minutes|Self|10 minutes|V,S,M|Concentration|   |
|[[Shapechange]]|9|transmutation|Action|Self|1 hour|V,S,M|Concentration|   |
|[[Shillelagh]]|0|transmutation|Bonus Action|Self|1 minute|V,S,M|||
|[[Sleet Storm]]|3|conjuration|Action|150 ft|1 minute|V,S,M|Concentration|   |
|[[Spare the Dying]]|0|necromancy|Action|15 ft|Instantaneous|V,S|||
|[[Speak with Animals]]|1|divination|Action or Ritual|Self|10 minutes|V,S||Ritual|
|[[Speak with Plants]]|3|transmutation|Action|Self|10 minutes|V,S|||
|[[Spike Growth]]|2|transmutation|Action|150 ft|10 minutes|V,S,M|Concentration|   |
|[[Starry Wisp]]|0|evocation|Action|60 ft|Instantaneous|V,S|||
|[[Stone Shape]]|4|transmutation|Action|Touch|Instantaneous|V,S,M|||
|[[Stoneskin]]|4|transmutation|Action|Touch|1 hour|V,S,M|Concentration|   |
|[[Storm of Vengeance]]|9|conjuration|Action|1 mile|1 minute|V,S|Concentration|   |
|[[Summon Beast]]|2|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Summon Elemental]]|4|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Summon Fey]]|3|conjuration|Action|90 ft|1 hour|V,S,M|Concentration|   |
|[[Sunbeam]]|6|evocation|Action|Self|1 minute|V,S,M|Concentration|   |
|[[Sunburst]]|8|evocation|Action|150 ft|Instantaneous|V,S,M|||
|[[Symbol]]|7|abjuration|1 minute|Touch|Dispelled or triggered|V,S,M|||
|[[Thorn Whip]]|0|transmutation|Action|30 ft|Instantaneous|V,S,M|||
|[[Thunderclap]]|0|evocation|Action|Self|Instantaneous|S|||
|[[Thunderwave]]|1|evocation|Action|Self|Instantaneous|V,S|||
|[[Transport via Plants]]|6|conjuration|Action|10 ft|1 minute|V,S|||
|[[Tree Stride]]|5|conjuration|Action|Self|1 minute|V,S|Concentration|   |
|[[True Resurrection]]|9|necromancy|1 hour|Touch|Instantaneous|V,S,M|||
|[[Tsunami]]|8|conjuration|1 minute|1 mile|6 rounds|V,S|Concentration|   |
|[[Wall of Fire]]|4|evocation|Action|120 ft|1 minute|V,S,M|Concentration|   |
|[[Wall of Stone]]|5|evocation|Action|120 ft|10 minutes|V,S,M|Concentration|   |
|[[Wall of Thorns]]|6|conjuration|Action|120 ft|10 minutes|V,S,M|Concentration|   |
|[[Water Breathing]]|3|transmutation|Action or Ritual|30 ft|24 hours|V,S,M||Ritual|
|[[Water Walk]]|3|transmutation|Action or Ritual|30 ft|1 hour|V,S,M||Ritual|
|[[Wind Walk]]|6|transmutation|1 minute|30 ft|8 hours|V,S,M|||
|[[Wind Wall]]|3|evocation|Action|120 ft|1 minute|V,S,M|Concentration|   |