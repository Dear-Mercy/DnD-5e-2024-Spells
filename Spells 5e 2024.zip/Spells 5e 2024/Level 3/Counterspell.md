level 3 - #abjuration Casting Time: #Reaction, which you take when you see a creature within 60 feet of yourself casting a spell with Verbal, Somatic, or Material components Range: 60 feet Components: S Duration: Instantaneous 

You attempt to interrupt a creature in the process of casting a spell. The creature must make a Constitution saving throw. On a failed save, the spell dissipates with no effect, and the action, Bonus Action, or Reaction used to cast it is wasted. If that spell was cast with a spell slot, the slot isn't expended


#Sorcerer #Warlock #Wizard
