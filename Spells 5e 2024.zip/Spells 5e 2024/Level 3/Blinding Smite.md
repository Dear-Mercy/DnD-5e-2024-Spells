level 3 - #evocation Casting Time: #BonusAction, which you take immediately after hitting a creature with a Melee weapon or an Unarmed Strike Range: Self Components: V Duration: 1 minute 

The target hit by the strike takes an extra 3d8 Radiant damage from the attack, and the target has the Blinded condition until the spell ends. At the end of each of its turns, the Blinded target makes a Constitution saving throw, ending the spell on itself on a success. 

Using a Higher-Level Spell Slot. The extra damage increases by 1d8 for each spell slot level above 3


#Paladin
