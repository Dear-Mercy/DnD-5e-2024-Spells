level 3 - #abjuration Casting Time: Action Range: Self Components: V Duration: #Concentration, up to 1 minute 

An aura radiates from you in a 30-foot Emanation for the duration. When you create the aura and at the start of each of your turns while it persists, you can restore 2d6 Hit Points to one creature in it.


#Cleric #Druid #Paladin
