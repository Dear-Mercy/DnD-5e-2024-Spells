level 3 - #evocation Casting Time: Action Range: Self Components: V Duration: #Concentration, up to 1 minute 

You radiate a magical aura in a 30-foot Emanation. While in the aura, you and your allies each deal an extra 1d4 Radiant damage when hitting with a weapon or an Unarmed Strike


#Paladin
