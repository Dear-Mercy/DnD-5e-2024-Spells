level 3 - #abjuration Casting Time: Action Range: 30 feet Components: V, S Duration: #Concentration, up to 1 minute 

Choose any number of creatures within range. For the duration, each target has Advantage on Wisdom saving throws and Death Saving Throws and regains the maximum number of Hit Points possible from any healing


#Cleric
