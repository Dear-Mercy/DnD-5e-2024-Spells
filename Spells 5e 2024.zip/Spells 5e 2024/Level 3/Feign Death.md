level 3 - #necromancy ( #ritual ) Casting Time: Action or Ritual Range: Touch Components: V, S, M (a pinch of graveyard dirt) Duration: 1 hour 

You touch a willing creature and put it into a cataleptic state that is indistinguishable from death. 
For the duration, the target appears dead to outward inspection and to spells used to determine the target's status. The target has the Blinded and Incapacitated conditions, and its Speed is 0. 
The target also has Resistance to all damage except Psychic damage, and it has Immunity to the Poisoned condition


#Bard #Cleric #Druid #Wizard
