level 3 - #transmutation ( #ritual ) Casting Time: Action or Ritual Range: 30 feet Components: V, S, M (a short reed) Duration: 24 hours 

This spell grants up to ten willing creatures of your choice within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration


#Druid #Ranger #Sorcerer #Wizard
