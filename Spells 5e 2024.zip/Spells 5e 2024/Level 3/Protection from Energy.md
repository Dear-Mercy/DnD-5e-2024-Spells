level 3 - #abjuration Casting Time: Action Range: Touch Components: V, S Duration: #Concentration, up to 1 hour 

For the duration, the willing creature you touch has Resistance to one damage type of your choice: Acid, Cold, Fire, Lightning, or Thunder


#Cleric #Druid #Ranger #Sorcerer #Wizard
