level 3 - #abjuration Casting Time: #BonusAction Range: 60 feet Components: V Duration: Instantaneous 

Up to six creatures of your choice that you can see within range regain Hit Points equal to 2d4 plus your spellcasting ability modifier. 

Using a Higher-Level Spell Slot. The healing increases by 1d4 for each spell slot level above 3.


#Bard #Cleric
