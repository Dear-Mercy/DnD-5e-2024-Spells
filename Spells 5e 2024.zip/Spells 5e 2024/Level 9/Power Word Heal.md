level 9 - #enchantment Casting Time: Action Range: 60 feet Components: V Duration: Instantaneous 

A wave of healing energy washes over one creature you can see within range. The target regains all its Hit Points. If the creature has the Charmed, Frightened, Paralyzed, Poisoned, or Stunned condition, the condition ends. If the creature has the Prone condition, it can use its Reaction to stand up


#Bard #Cleric
