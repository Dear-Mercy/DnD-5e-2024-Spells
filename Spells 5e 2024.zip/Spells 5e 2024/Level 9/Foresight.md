level 9 - #divination Casting Time: 1 minute Range: Touch Components: V, S, M (a hummingbird feather) Duration: 8 hours 

You touch a willing creature and bestow a limited ability to see into the immediate future. For the duration, the target has Advantage on D20 Tests, and other creatures have Disadvantage on attack rolls against it. The spell ends early if you cast it again


#Bard #Druid #Warlock #Wizard
