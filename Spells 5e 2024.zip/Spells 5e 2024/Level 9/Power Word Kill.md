level 9 - #enchantment Casting Time: Action Range: 60 feet Components: V Duration: Instantaneous 

You compel one creature you can see within range to die. If the target has 100 Hit Points or fewer, it dies. Otherwise, it takes 12d12 Psychic damage.


#Bard #Sorcerer #Warlock #Wizard
