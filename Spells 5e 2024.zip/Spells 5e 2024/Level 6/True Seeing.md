level 6 - #divination Casting Time: Action Range: Touch Components: V, S, M (mushroom powder worth 25+ GP, which the spell consumees) Duration: 1 hour 

For the duration, the willing creature you touch has Truesight with a range of 120 feet.


#Bard #Cleric #Sorcerer #Warlock #Wizard
