level 6 - #abjuration Casting Time: Action Range: 60 feet Components: V, S Duration: Instantaneous 

Choose a creature that you can see within range. Positive energy washes through the target, restoring 70 Hit Points. This spell also ends the Blinded, Deafened, and Poisoned conditions on the target. 

Using a Higher-Level Spell Slot. The healing increases by 10 for each spell slot level above 6.


#Cleric #Druid
