level 6 - #enchantment Casting Time: Action Range: 30 feet Components: V Duration: #Concentration, up to 1 minute 

Description not available (not OGL)


#Bard #Wizard
