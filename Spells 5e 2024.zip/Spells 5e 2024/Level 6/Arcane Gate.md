level 6 - #conjuration Casting Time: Action Range: 500 feet Components: V, S Duration: #Concentration, up to 10 minutes

Description not available (not OGL).


#Sorcerer #Warlock #Wizard
