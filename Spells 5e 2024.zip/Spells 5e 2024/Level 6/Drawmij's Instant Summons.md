level 6 - #conjuration ( #ritual )  Casting Time: 1 minute or Ritual Range: Touch Components: V, S, M (a sapphire worth 1,000+ GP) Duration: Until dispelled 

Description not available (not OGL)


#Wizard
