level 6 - #evocation Casting Time: Action Range: 300 feet Components: V, S, M (a small crystal sphere) Duration: Instantaneous 

Description not available (not OGL)


#Sorcerer #Wizard
