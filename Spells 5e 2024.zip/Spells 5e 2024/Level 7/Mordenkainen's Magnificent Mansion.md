level 7 - #conjuration Casting Time: 1 minute Range: 300 feet Components: V, S, M (a miniature door worth 15+ GP) Duration: 24 hours 

Description not available (not OGL)


#Bard #Wizard
