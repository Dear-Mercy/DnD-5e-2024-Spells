level 7 - #enchantment Casting Time: Action Range: 60 feet Components: V Duration: Instantaneous 

Description not available (not OGL)


#Bard #Cleric
