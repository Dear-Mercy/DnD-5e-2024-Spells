level 2 - #illusion Casting Time: Action Range: Self Components: V Duration: #Concentration, up to 1 minute 

Your body becomes blurred. For the duration, any creature has Disadvantage on attack rolls against you. An attacker is immune to this effect if it perceives you with Blindsight or Truesight.


#Sorcerer #Wizard
