level 2 - #transmutation Casting Time: #BonusAction, which you take immediately after hitting a creature with a Melee weapon or an Unarmed Strike Range: Self Components: V Duration: #Concentration, up to 1 minute 

The target hit by the strike takes an extra 2d6 Radiant damage from the attack. Until the spell ends, the target sheds Bright Light in a 5-foot radius, attack rolls against it have Advantage, and it can't benefit from the Invisible condition. 

Using a Higher-Level Spell Slot. The damage increases by 1d6 for each spell slot level above 2


#Paladin
