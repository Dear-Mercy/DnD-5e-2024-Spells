level 2 - #transmutation Casting Time: Action Range: Touch Components: V, S, M (fur or a feather) Duration: #Concentration, up to 1 hour 

You touch a creature and choose Strength, Dexterity, Intelligence, Wisdom, or Charisma. For the duration, the target has Advantage on ability checks using the chosen ability. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 2. You can choose a different ability for each target


#Bard #Cleric #Druid #Ranger #Sorcerer #Wizard
