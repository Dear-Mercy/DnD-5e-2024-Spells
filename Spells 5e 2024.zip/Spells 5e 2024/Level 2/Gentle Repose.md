level 2 - #necromancy ( #ritual ) Casting Time: Action or Ritual Range: Touch Components: V, S, M (2 copper pieces, which the spell consume) Duration: 10 days 

You touch a corpse or other remains. For the duration, the target is protected from decay and can't become Undead. 
The spell also effectively extends the time limit on raising the target from the dead, since days spent under the influence of this spell don't count against the time limit of spells such as Raise Dead


#Cleric #Paladin #Wizard
