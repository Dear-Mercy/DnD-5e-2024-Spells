level 2 - #transmutation Casting Time: #BonusAction Range: Touch Components: V, S Duration: 1 hour 

You touch a nonmagical weapon. Until the spell ends, that weapon becomes a magic weapon with a +1 bonus to attack rolls and damage rolls. The spell ends early if you cast it again. 

Using a Higher-Level Spell Slot. The bonus increases to +2 with a level 3–5 spell slot. The bonus increases to +3 with a level 6+ spell slot.


#Paladin #Ranger #Sorcerer #Wizard
