Level 2 - #conjuration Casting Time: #BonusAction Range: Self Components: V Duration: Instantaneous 

Briefly surrounded by silvery mist, you teleport up to 30 feet to an unoccupied space you can see.


#Sorcerer #Warlock #Wizard
