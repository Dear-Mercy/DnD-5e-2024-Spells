level 2 - #abjuration Casting Time: Action Range: 30 feet Components: V, S, M (a strip of white cloth) Duration: 8 hours 

Choose up to three creatures within range. Each target's Hit Point maximum and current Hit Points increase by 5 for the duration. 

Using a Higher-Level Spell Slot. Each target's Hit Points increase by 5 for each spell slot level above 2.


#Bard #Cleric #Druid #Paladin #Ranger
