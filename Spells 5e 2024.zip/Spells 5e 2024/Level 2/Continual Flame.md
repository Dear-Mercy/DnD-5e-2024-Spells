level 2 - #evocation Casting Time: Action Range: Touch Components: V, S, M (ruby dust worth 50+ GP, which the spell consumes) Duration: Until dispelled 

A flame springs from an object that you touch. The effect casts Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. It looks like a regular flame, but it creates no heat and consumes no fuel. The flame can be covered or hidden but not smothered or quenched.


#Cleric #Druid #Wizard
