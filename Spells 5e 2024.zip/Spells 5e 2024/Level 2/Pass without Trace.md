level 2 - #abjuration Casting Time: Action Range: Self Components: V, S, M (ashes from a burned mistletoe) Duration: #Concentration, up to 1 hour 

You radiate a concealing aura in a 30-foot Emanation for the duration. While in the aura, you and each creature you choose have a +10 bonus to Dexterity (Stealth) checks and leave no tracks.


#Druid #Ranger
