level 2 - #abjuration Casting Time: #BonusAction Range: Touch Components: V, S Duration: Instantaneous 

You touch a creature and end one condition on it: Blinded, Deafened, Paralyzed, or Poisoned


#Bard #Cleric #Druid #Paladin #Ranger
