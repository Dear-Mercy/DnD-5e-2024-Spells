level 2 - #divination ( #ritual ) Casting Time: Action or Ritual Range: Self Components: V, S, M (fur from a bloodhound) Duration: Instantaneous 

Describe or name a specific kind of Beast, Plant creature, or nonmagical plant. You learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present


#Bard #Druid #Ranger
