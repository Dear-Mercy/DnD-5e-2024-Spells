level 2 - #transmutation Casting Time: #BonusAction Range: Touch Components: V, S, M (a hot pepper) Duration: #Concentration, up to 1 minute 

You touch one willing creature, and choose Acid, Cold, Fire, Lightning, or Poison. Until the spell ends, the target can take a Magic action to exhale a 15-foot Cone. Each creature in that area makes a Dexterity saving throw, taking 3d6 damage of the chosen type on a failed save or half as much damage on a successful one. 

Using a Higher-Level Spell Slot. The damage increases by 1d6 for each spell slot level above 2.


#Sorcerer #Wizard
