level 2 - #divination ( #ritual ) Casting Time: Action or Ritual Range: Touch Components: S Duration: #Concentration, up to 1 hour 

You touch a willing Beast. For the duration, you can perceive through the Beast's senses as well as your own. When perceiving through the Beast's senses, you benefit from any special senses it has


#Druid #Ranger
