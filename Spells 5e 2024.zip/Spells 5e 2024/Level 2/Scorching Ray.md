level 2 - #evocation Casting Time: Action Range: 120 feet Components: V, S Duration: Instantaneous 

You hurl three fiery rays. You can hurl them at one target within range or at several. Make a ranged spell attack for each ray. On a hit, the target takes 2d6 Fire damage. 

Using a Higher-Level Spell Slot. You create one additional ray for each spell slot level above 2


#Sorcerer #Wizard
