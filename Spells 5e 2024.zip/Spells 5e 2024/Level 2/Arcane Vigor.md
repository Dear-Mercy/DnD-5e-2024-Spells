level 2 - #abjuration Casting Time: #BonusAction Range: Self Components: V, S Duration: Instantaneous 

You tap into your life force to heal yourself. Roll one or two of your unexpended Hit Point Dice, and regain a number of Hit Points equal to the roll's total plus your spellcasting ability modifier. Those dice are then expended. 
Using a Higher-Level Spell Slot. The number of unexpended Hit Dice you can roll increases by one for each spell slot level above 2.


#Sorcerer #Wizard
