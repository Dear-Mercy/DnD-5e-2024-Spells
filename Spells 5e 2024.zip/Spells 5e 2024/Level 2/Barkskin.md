level 2 - #transmutation Casting Time: #BonusAction Range: Touch Components: V, S, M (a handful of bark) Duration: 1 hour 

You touch a willing creature. Until the spell ends, the target's skin assumes a bark-like appearance, and the target has an Armor Class of 17 if its AC is lower than that.


#Druid #Ranger
