level 2 - #transmutation Casting Time: Action Range: Touch Components: V, S, M (a dried carrot) Duration: 8 hours 

For the duration, a willing creature you touch has Darkvision with a range of 150 feet


#Druid #Ranger #Sorcerer #Wizard
