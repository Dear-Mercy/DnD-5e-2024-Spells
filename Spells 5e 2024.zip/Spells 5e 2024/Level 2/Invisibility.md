level 2 - #illusion Casting Time: Action Range: Touch Components: V, S, M (an eyelash in gum arabic) Duration: #Concentration, up to 1 hour 

A creature you touch has the Invisible condition until the spell ends. The spell ends early immediately after the target makes an attack roll, deals damage, or casts a spell. 

Using a Higher-Level Spell Slot. You can target one additional creature for each spell slot level above 2


#Bard #Sorcerer #Warlock #Wizard
