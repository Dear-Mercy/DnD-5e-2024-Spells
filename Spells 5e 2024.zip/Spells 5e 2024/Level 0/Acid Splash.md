level 0 - #evocation Casting Time: Action Range: 60 feet Components: V, S Duration: Instantaneous

You create an acidic bubble at a point within range, where it explodes in a 5-foot-radius Sphere. Each creature in that Sphere must succeed on a Dexterity saving throw or take 1d6 Acid damage. 

Cantrip Upgrade. The damage increases by 1d6 when you reach levels 5 (2d6), 11 (3d6), and 17 (4d6)


#Sorcerer #Wizard
