level 0 - #evocation Casting Time: Action Range: Self Components: V, M (a sunburst token) Duration: Instantaneous 

Burning radiance erupts from you in a 5-foot Emanation. Each creature of your choice that you can see in it must succeed on a Constitution saving throw or take 1d6 Radiant damage. 

Cantrip Upgrade. The damage increases by 1d6 when you reach levels 5 (2d6), 11 (3d6), and 17 (4d6).


#Cleric
