level 0 - #abjuration Casting Time: Action Range: Self Components: V, S Duration: #Concentration, up to 1 minute 

Whenever a creature makes an attack roll against you before the spell ends, the attacker subtracts 1d4 from the attack roll


#Bard #Sorcerer #Warlock #Wizard
