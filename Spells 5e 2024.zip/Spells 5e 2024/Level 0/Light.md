level 0 - #evocation Casting Time: Action Range: Touch Components: V, M (a firefly or phosphorescent moss) Duration: 1 hour 

You touch one Large or smaller object that isn't being worn or carried by someone else. Until the spell ends, the object sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. The light can be colored as you like. 
Covering the object with something opaque blocks the light. The spell ends if you cast it again.


#Bard #Cleric #Sorcerer #Wizard
