level 0 - #evocation Casting Time: Action Range: Self Components: S Duration: Instantaneous 

Each creature in a 5-foot Emanation originating from you must succeed on a Constitution saving throw or take 1d6 Thunder damage. The spell's thunderous sound can be heard up to 100 feet away. 

Cantrip Upgrade. The damage increases by 1d6 when you reach levels 5 (2d6), 11 (3d6), and 17 (4d6)


#Bard #Druid #Sorcerer #Warlock #Wizard
