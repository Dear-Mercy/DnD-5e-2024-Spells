level 0 - #necromancy Casting Time: Action Range: Touch Components: V, S Duration: Instantaneous 
 
 Channeling the chill of the grave, make a melee spell attack against a target within reach. On a hit, the target takes 1d10 Necrotic damage, and it can't regain Hit Points until the end of your next turn. 
 
 Cantrip Upgrade. The damage increases by 1d10 when you reach levels 5 (2d10), 11 (3d10), and 17 (4d10).


#Sorcerer #Warlock #Wizard
