level 0 - #enchantment Casting Time: Action Range: 60 feet Components: V Duration: Instantaneous 

You unleash a string of insults laced with subtle enchantments at one creature you can see or hear within range. The target must succeed on a Wisdom saving throw or take 1d6 Psychic damage and have Disadvantage on the next attack roll it makes before the end of its next turn. 

Cantrip Upgrade. The damage increases by 1d6 when you reach level 5 (2d6), level 11 (3d6), and level 17 (4d6).


#Bard
